from app.database.connection import Base, SessionLocal, engine
from app.database.migrations import run_lightweight_migrations
from app.services.discovery import seed_available_sensors


def discover_test_sensors() -> None:
    Base.metadata.create_all(bind=engine)
    run_lightweight_migrations(engine)

    db = SessionLocal()
    try:
        sensors = seed_available_sensors(db)
        print("Available test sensors discovered:")
        for sensor in sensors:
            status = "installed" if sensor.is_installed else "available"
            print(f"- {sensor.device_uid}: {sensor.name} ({sensor.manufacturer}, {status})")
    finally:
        db.close()


if __name__ == "__main__":
    discover_test_sensors()
