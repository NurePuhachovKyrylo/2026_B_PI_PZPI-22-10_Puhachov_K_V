# Bridge Monitoring Backend

FastAPI backend for a bridge monitoring system. It stores bridges, inspectors,
sensors, sensor readings, alerts, users and role-based access rules in SQLite.

## Implemented

- SQLite database setup through SQLAlchemy models.
- CRUD for bridges.
- CRUD for inspectors.
- CRUD for sensors with bridge binding.
- Sensor types: temperature, vibration, humidity, deformation, pressure, wind,
  water_level, corrosion and other.
- Saving sensor readings and keeping full reading history.
- Chart-ready time series endpoint by period: day, week or month.
- Automatic threshold checks for sensor values.
- Alert creation for dangerous readings.
- Bridge status recalculation: normal, warning or danger.
- Bridge problem details showing which sensor caused the dangerous status.
- Discovered sensors catalog and installation flow.
- Sensor metadata: manufacturer, installer, responsible inspector and Ukrainian description.
- Read-only sensor readings for users; device ingestion uses a separate endpoint.
- JSON auth with bearer tokens.
- Roles: admin, inspector and user.
- Role-based permissions.
- Search, filtering and sorting for table endpoints.
- Static frontend served by FastAPI.
- Sensor emulator program.
- Demo data generator.
- Simple load test program.

## Install

```bash
pip install -r requirements.txt
```

## Run API

```bash
uvicorn app.main:app --reload
```

On Windows you can also use:

```bash
python run_server.py --reload
```

Frontend:

```text
http://127.0.0.1:8000/
```

API docs:

```text
http://127.0.0.1:8000/docs
```

Health:

```http
GET /health
```

## First User

Register the first account. The first user becomes an admin if no users exist.

```http
POST /auth/register
```

```json
{
  "username": "admin",
  "password": "admin123"
}
```

Login:

```http
POST /auth/login
```

```json
{
  "username": "admin",
  "password": "admin123"
}
```

Use the returned token as:

```text
Authorization: Bearer <token>
```

## Main Endpoints

Auth and users:

- `POST /auth/register`
- `POST /auth/login`
- `GET /auth/me`
- `POST /auth/users`
- `GET /auth/users`
- `GET /auth/users/{user_id}`
- `PUT /auth/users/{user_id}`
- `DELETE /auth/users/{user_id}`

Bridges:

- `POST /bridges`
- `GET /bridges?search=Kyiv&status=normal&sort_by=name&sort_dir=asc`
- `GET /bridges/{bridge_id}`
- `PUT /bridges/{bridge_id}`
- `DELETE /bridges/{bridge_id}`

Inspectors:

- `POST /inspectors`
- `GET /inspectors?search=engineer&sort_by=full_name`
- `GET /inspectors/{inspector_id}`
- `PUT /inspectors/{inspector_id}`
- `DELETE /inspectors/{inspector_id}`

Sensors:

- `GET /sensors/types`
- `GET /sensors/available`
- `POST /sensors/available/seed`
- `POST /sensors/available/{available_sensor_id}/install`
- `GET /sensors?bridge_id=1&sensor_type=vibration&is_active=true`
- `GET /sensors/{sensor_id}`
- `PUT /sensors/{sensor_id}`
- `DELETE /sensors/{sensor_id}`

Readings and chart data:

- `POST /readings/ingest`
- `GET /readings?sensor_id=1&sort_dir=asc`
- `GET /readings/{reading_id}`
- `GET /readings/sensors/{sensor_id}/chart?period=day`
- `GET /readings/sensors/{sensor_id}/chart?period=week`
- `GET /readings/sensors/{sensor_id}/chart?period=month`

Alerts:

- `GET /alerts?is_resolved=false&alert_level=danger`
- `GET /alerts/{alert_id}`
- `PUT /alerts/{alert_id}`

Bridge problem details:

- `GET /bridges/{bridge_id}/problems`

## Permissions

- `admin`: full access, including users and delete operations.
- `inspector`: can create and update bridges, sensors, readings and alerts.
- `user`: read-only access.

## Demo Data

Create demo bridges, inspectors, sensors, readings and admin user:

```bash
python seed_demo_data.py
```

Only discover available test sensors:

```bash
python discover_test_sensors.py
```

Optional:

```bash
python seed_demo_data.py --days 30 --points-per-day 8 --danger-rate 0.1
```

Default demo admin:

```text
username: admin
password: admin123
```

## Sensor Emulator

Generate live-like sensor readings:

```bash
python sensor_emulator.py --iterations 50 --delay 1 --danger-rate 0.12
```

For real device-style HTTP ingestion use:

```http
POST /readings/ingest
X-Device-Token: dev-device-token
```

Set `BRIDGE_DEVICE_INGEST_TOKEN` in the environment for a non-demo token.

Limit to one bridge or sensor:

```bash
python sensor_emulator.py --bridge-id 1
python sensor_emulator.py --sensor-id 3
```

## Load Test

Run the API first, seed demo data, then:

```bash
python load_test.py --requests 500 --concurrency 25 --endpoint /bridges
```

The program prints total time, requests per second, status codes and latency
summary.
