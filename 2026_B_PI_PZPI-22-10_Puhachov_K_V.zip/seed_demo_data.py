import argparse
import random
from datetime import datetime, timedelta

from app.core.security import hash_password
from app.database.connection import Base, SessionLocal, engine
from app.database.migrations import run_lightweight_migrations
from app.database.models import Bridge, Inspector, Sensor, User
from app.services.discovery import seed_available_sensors
from app.services.monitoring import record_sensor_reading


def ensure_admin(db) -> User:
    user = db.query(User).filter(User.username == "admin").first()
    if user:
        return user

    user = User(
        username="admin",
        password_hash=hash_password("admin123"),
        role="admin",
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def ensure_inspectors(db) -> list[Inspector]:
    inspectors = [
        {
            "full_name": "Olena Kovalenko",
            "email": "olena.kovalenko@example.com",
            "phone": "+380501112233",
            "position": "Senior bridge inspector",
        },
        {
            "full_name": "Andrii Shevchenko",
            "email": "andrii.shevchenko@example.com",
            "phone": "+380671234567",
            "position": "Structural engineer",
        },
    ]

    result = []
    for inspector_data in inspectors:
        inspector = db.query(Inspector).filter(Inspector.email == inspector_data["email"]).first()
        if inspector is None:
            inspector = Inspector(**inspector_data)
            db.add(inspector)
            db.commit()
            db.refresh(inspector)
        result.append(inspector)

    return result


def ensure_bridges(db) -> list[Bridge]:
    bridges = [
        {
            "name": "North Bridge",
            "location": "Kyiv",
            "description": "Urban bridge over the river.",
        },
        {
            "name": "Harbor Bridge",
            "location": "Odesa",
            "description": "Bridge near port infrastructure.",
        },
        {
            "name": "Central Overpass",
            "location": "Lviv",
            "description": "Road overpass with heavy daily traffic.",
        },
    ]

    result = []
    for bridge_data in bridges:
        bridge = db.query(Bridge).filter(Bridge.name == bridge_data["name"]).first()
        if bridge is None:
            bridge = Bridge(**bridge_data)
            db.add(bridge)
            db.commit()
            db.refresh(bridge)
        result.append(bridge)

    return result


def sensor_description_uk(sensor_type: str) -> str:
    descriptions = {
        "temperature": (
            "Температурний датчик контролює умови експлуатації мосту та допомагає "
            "пояснювати сезонні зміни деформації конструкції."
        ),
        "vibration": (
            "Вібраційний датчик фіксує коливання мосту від транспорту, вітру та "
            "можливих дефектів несучих елементів."
        ),
        "humidity": (
            "Датчик вологості потрібен для оцінки ризику корозії металевих деталей "
            "і погіршення стану бетонних елементів."
        ),
        "deformation": (
            "Датчик деформації відстежує зміщення та розкриття стиків. Небезпечні "
            "значення можуть вказувати на перевантаження або розвиток дефекту."
        ),
    }
    return descriptions.get(sensor_type, "Датчик використовується для технічного моніторингу стану мосту.")


def ensure_sensors(
    db,
    bridges: list[Bridge],
    inspectors: list[Inspector],
) -> list[Sensor]:
    sensor_templates = [
        ("Temperature", "temperature", "C", -30.0, 70.0, "Milesight"),
        ("Vibration", "vibration", "mm/s", 0.0, 25.0, "Analog Devices"),
        ("Humidity", "humidity", "%", 0.0, 95.0, "Bosch Sensortec"),
        ("Deformation", "deformation", "mm", -8.0, 8.0, "GEOKON"),
    ]
    sensors = []

    for bridge in bridges:
        for index, (name, sensor_type, unit, min_value, max_value, manufacturer) in enumerate(sensor_templates):
            sensor_name = f"{bridge.name} {name}"
            sensor = db.query(Sensor).filter(Sensor.name == sensor_name).first()
            if sensor is None:
                sensor = Sensor(
                    bridge_id=bridge.id,
                    name=sensor_name,
                    sensor_type=sensor_type,
                    unit=unit,
                    min_value=min_value,
                    max_value=max_value,
                    is_active=True,
                    manufacturer=manufacturer,
                    installed_by="Auto-discovery demo installer",
                    responsible_inspector_id=inspectors[index % len(inspectors)].id if inspectors else None,
                    description_uk=sensor_description_uk(sensor_type),
                )
                db.add(sensor)
                db.commit()
                db.refresh(sensor)
            else:
                sensor.manufacturer = sensor.manufacturer or manufacturer
                sensor.installed_by = sensor.installed_by or "Auto-discovery demo installer"
                sensor.responsible_inspector_id = (
                    sensor.responsible_inspector_id
                    or (inspectors[index % len(inspectors)].id if inspectors else None)
                )
                sensor.description_uk = sensor.description_uk or sensor_description_uk(sensor_type)
                db.commit()
                db.refresh(sensor)
            sensors.append(sensor)

    return sensors


def generate_value(sensor: Sensor, danger_rate: float) -> float:
    safe_range = sensor.max_value - sensor.min_value
    if random.random() < danger_rate:
        direction = random.choice([-1, 1])
        overflow = random.uniform(0.05, 0.35) * safe_range
        if direction < 0:
            return round(sensor.min_value - overflow, 2)
        return round(sensor.max_value + overflow, 2)

    return round(random.uniform(sensor.min_value, sensor.max_value), 2)


def seed_readings(db, sensors: list[Sensor], days: int, points_per_day: int, danger_rate: float) -> int:
    created = 0
    now = datetime.utcnow()
    total_points = max(days * points_per_day, 1)

    for sensor in sensors:
        for index in range(total_points):
            offset_hours = (days * 24 / total_points) * index
            recorded_at = now - timedelta(hours=offset_hours)
            record_sensor_reading(
                db=db,
                sensor=sensor,
                value=generate_value(sensor, danger_rate),
                recorded_at=recorded_at,
            )
            created += 1

    return created


def seed_demo_data(days: int, points_per_day: int, danger_rate: float) -> None:
    Base.metadata.create_all(bind=engine)
    run_lightweight_migrations(engine)
    db = SessionLocal()
    try:
        ensure_admin(db)
        inspectors = ensure_inspectors(db)
        seed_available_sensors(db)
        bridges = ensure_bridges(db)
        sensors = ensure_sensors(db, bridges, inspectors)
        created = seed_readings(
            db=db,
            sensors=sensors,
            days=days,
            points_per_day=points_per_day,
            danger_rate=danger_rate,
        )
        print("Demo data is ready.")
        print("Admin login: admin")
        print("Admin password: admin123")
        print(f"Bridges: {len(bridges)}")
        print(f"Sensors: {len(sensors)}")
        print(f"Readings generated: {created}")
    finally:
        db.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Seed demo data for Bridge Monitoring API.")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--points-per-day", type=int, default=4)
    parser.add_argument("--danger-rate", type=float, default=0.08)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    seed_demo_data(
        days=args.days,
        points_per_day=args.points_per_day,
        danger_rate=args.danger_rate,
    )
