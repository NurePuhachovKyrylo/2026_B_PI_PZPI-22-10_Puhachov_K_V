import argparse
import json
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


def request_json(url: str, method: str = "GET", token: str | None = None, payload: dict | None = None):
    data = None
    headers = {"Accept": "application/json"}

    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"

    if token:
        headers["Authorization"] = f"Bearer {token}"

    request = Request(url=url, data=data, headers=headers, method=method)
    started_at = time.perf_counter()

    try:
        with urlopen(request, timeout=15) as response:
            body = response.read()
            elapsed = time.perf_counter() - started_at
            return response.status, elapsed, body
    except HTTPError as exc:
        elapsed = time.perf_counter() - started_at
        return exc.code, elapsed, exc.read()
    except URLError as exc:
        elapsed = time.perf_counter() - started_at
        return 0, elapsed, str(exc).encode("utf-8")


def login(base_url: str, username: str, password: str) -> str:
    status_code, _, body = request_json(
        url=f"{base_url}/auth/login",
        method="POST",
        payload={"username": username, "password": password},
    )
    if status_code != 200:
        raise RuntimeError(
            "Login failed. Seed demo data first or pass valid --username and --password."
        )

    return json.loads(body.decode("utf-8"))["access_token"]


def run_load_test(
    base_url: str,
    endpoint: str,
    requests_count: int,
    concurrency: int,
    username: str,
    password: str,
) -> None:
    token = login(base_url=base_url, username=username, password=password)
    target_url = f"{base_url}{endpoint}"
    results = []
    started_at = time.perf_counter()

    with ThreadPoolExecutor(max_workers=concurrency) as executor:
        futures = [
            executor.submit(request_json, target_url, "GET", token, None)
            for _ in range(requests_count)
        ]
        for future in as_completed(futures):
            results.append(future.result())

    total_elapsed = time.perf_counter() - started_at
    status_codes = {}
    latencies = []

    for status_code, elapsed, _ in results:
        status_codes[status_code] = status_codes.get(status_code, 0) + 1
        latencies.append(elapsed)

    print(f"Target: {target_url}")
    print(f"Requests: {requests_count}")
    print(f"Concurrency: {concurrency}")
    print(f"Total time: {total_elapsed:.3f}s")
    print(f"Requests/sec: {requests_count / total_elapsed:.2f}")
    print(f"Status codes: {status_codes}")
    print(f"Latency min: {min(latencies):.4f}s")
    print(f"Latency avg: {statistics.mean(latencies):.4f}s")
    print(f"Latency max: {max(latencies):.4f}s")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Simple local load test for Bridge Monitoring API.")
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--endpoint", default="/bridges")
    parser.add_argument("--requests", type=int, default=100)
    parser.add_argument("--concurrency", type=int, default=10)
    parser.add_argument("--username", default="admin")
    parser.add_argument("--password", default="admin123")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_load_test(
        base_url=args.base_url.rstrip("/"),
        endpoint=args.endpoint,
        requests_count=args.requests,
        concurrency=args.concurrency,
        username=args.username,
        password=args.password,
    )
