from app.database.connection import Base, engine
from app.database import models
from app.database.migrations import run_lightweight_migrations


def create_database() -> None:
    Base.metadata.create_all(bind=engine)
    run_lightweight_migrations(engine)
    print("Database created successfully.")


if __name__ == "__main__":
    create_database()
