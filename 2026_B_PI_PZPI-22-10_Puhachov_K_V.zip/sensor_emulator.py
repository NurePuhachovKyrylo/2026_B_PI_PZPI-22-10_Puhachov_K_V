import argparse
import random
import time

from app.database.connection import Base, SessionLocal, engine
from app.database.migrations import run_lightweight_migrations
from app.database.models import Sensor
from app.services.monitoring import record_sensor_reading


def generate_value(sensor: Sensor, danger_rate: float) -> float:
    safe_range = sensor.max_value - sensor.min_value
    if random.random() < danger_rate:
        overflow = random.uniform(0.05, 0.35) * max(safe_range, 1.0)
        if random.choice([True, False]):
            return round(sensor.min_value - overflow, 2)
        return round(sensor.max_value + overflow, 2)

    return round(random.uniform(sensor.min_value, sensor.max_value), 2)


def get_active_sensors(db, sensor_id: int | None, bridge_id: int | None) -> list[Sensor]:
    query = db.query(Sensor).filter(Sensor.is_active.is_(True))

    if sensor_id:
        query = query.filter(Sensor.id == sensor_id)

    if bridge_id:
        query = query.filter(Sensor.bridge_id == bridge_id)

    return query.order_by(Sensor.id.asc()).all()


def run_emulator(
    iterations: int,
    delay: float,
    danger_rate: float,
    sensor_id: int | None,
    bridge_id: int | None,
) -> None:
    Base.metadata.create_all(bind=engine)
    run_lightweight_migrations(engine)
    db = SessionLocal()
    try:
        sensors = get_active_sensors(db=db, sensor_id=sensor_id, bridge_id=bridge_id)
        if not sensors:
            print("No active sensors found. Run seed_demo_data.py or create sensors through the API.")
            return

        for index in range(iterations):
            sensor = random.choice(sensors)
            value = generate_value(sensor, danger_rate)
            reading, alert = record_sensor_reading(db=db, sensor=sensor, value=value)
            alert_text = f", alert={alert.alert_level}" if alert else ""
            print(
                f"{index + 1}/{iterations}: sensor={sensor.id} "
                f"value={reading.value} {sensor.unit}{alert_text}"
            )
            if delay > 0 and index < iterations - 1:
                time.sleep(delay)
    finally:
        db.close()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate sensor readings without real hardware.")
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument("--delay", type=float, default=1.0)
    parser.add_argument("--danger-rate", type=float, default=0.1)
    parser.add_argument("--sensor-id", type=int, default=None)
    parser.add_argument("--bridge-id", type=int, default=None)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_emulator(
        iterations=args.iterations,
        delay=args.delay,
        danger_rate=args.danger_rate,
        sensor_id=args.sensor_id,
        bridge_id=args.bridge_id,
    )
