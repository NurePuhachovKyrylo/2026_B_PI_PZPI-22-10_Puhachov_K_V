from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database.models import Inspector
from app.schemas.inspectors import InspectorCreate, InspectorUpdate


def create_inspector(db: Session, inspector_data: InspectorCreate) -> Inspector:
    inspector = Inspector(**inspector_data.model_dump())
    db.add(inspector)
    db.commit()
    db.refresh(inspector)
    return inspector


def get_inspector_by_id(db: Session, inspector_id: int) -> Inspector | None:
    return db.query(Inspector).filter(Inspector.id == inspector_id).first()


def get_inspector_by_email(db: Session, email: str) -> Inspector | None:
    return db.query(Inspector).filter(Inspector.email == email).first()


def get_inspectors(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    search: str | None = None,
    sort_by: str = "id",
    sort_dir: str = "desc",
) -> list[Inspector]:
    query = db.query(Inspector)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                Inspector.full_name.ilike(search_pattern),
                Inspector.email.ilike(search_pattern),
                Inspector.position.ilike(search_pattern),
            )
        )

    sort_columns = {
        "id": Inspector.id,
        "full_name": Inspector.full_name,
        "email": Inspector.email,
        "position": Inspector.position,
        "created_at": Inspector.created_at,
    }
    sort_column = sort_columns.get(sort_by, Inspector.id)
    if sort_dir == "asc":
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    return query.offset(skip).limit(limit).all()


def update_inspector(
    db: Session,
    inspector: Inspector,
    inspector_data: InspectorUpdate,
) -> Inspector:
    update_data = inspector_data.model_dump(exclude_unset=True)

    for field, value in update_data.items():
        setattr(inspector, field, value)

    db.commit()
    db.refresh(inspector)
    return inspector


def delete_inspector(db: Session, inspector: Inspector) -> None:
    db.delete(inspector)
    db.commit()
