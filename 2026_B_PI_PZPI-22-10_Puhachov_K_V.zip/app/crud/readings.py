from datetime import datetime

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database.models import SensorReading


def get_reading_by_id(db: Session, reading_id: int) -> SensorReading | None:
    return db.query(SensorReading).filter(SensorReading.id == reading_id).first()


def get_readings(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    sensor_id: int | None = None,
    bridge_id: int | None = None,
    start_at: datetime | None = None,
    end_at: datetime | None = None,
    sort_dir: str = "desc",
) -> list[SensorReading]:
    query = db.query(SensorReading)

    if bridge_id:
        from app.database.models import Sensor

        query = query.join(Sensor, Sensor.id == SensorReading.sensor_id).filter(
            Sensor.bridge_id == bridge_id
        )

    if sensor_id:
        query = query.filter(SensorReading.sensor_id == sensor_id)

    if start_at:
        query = query.filter(SensorReading.recorded_at >= start_at)

    if end_at:
        query = query.filter(SensorReading.recorded_at <= end_at)

    if sort_dir == "asc":
        query = query.order_by(SensorReading.recorded_at.asc())
    else:
        query = query.order_by(SensorReading.recorded_at.desc())

    return query.offset(skip).limit(limit).all()


def get_reading_summary(
    db: Session,
    sensor_id: int,
    start_at: datetime,
) -> tuple[float | None, float | None, float | None, int]:
    row = (
        db.query(
            func.min(SensorReading.value),
            func.max(SensorReading.value),
            func.avg(SensorReading.value),
            func.count(SensorReading.id),
        )
        .filter(SensorReading.sensor_id == sensor_id)
        .filter(SensorReading.recorded_at >= start_at)
        .one()
    )
    return row[0], row[1], row[2], row[3]
