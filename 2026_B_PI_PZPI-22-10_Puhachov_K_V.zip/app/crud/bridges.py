from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database.models import Bridge
from app.schemas.bridges import BridgeCreate, BridgeUpdate


def create_bridge(db: Session, bridge_data: BridgeCreate) -> Bridge:
    bridge = Bridge(**bridge_data.model_dump())
    db.add(bridge)
    db.commit()
    db.refresh(bridge)
    return bridge


def get_bridges(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    search: str | None = None,
    status: str | None = None,
    sort_by: str = "id",
    sort_dir: str = "desc",
) -> list[Bridge]:
    query = db.query(Bridge)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                Bridge.name.ilike(search_pattern),
                Bridge.location.ilike(search_pattern),
            )
        )

    if status:
        query = query.filter(Bridge.status == status)

    sort_columns = {
        "id": Bridge.id,
        "name": Bridge.name,
        "location": Bridge.location,
        "status": Bridge.status,
        "created_at": Bridge.created_at,
    }
    sort_column = sort_columns.get(sort_by, Bridge.id)
    if sort_dir == "asc":
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    return query.offset(skip).limit(limit).all()


def get_bridge_by_id(db: Session, bridge_id: int) -> Bridge | None:
    return db.query(Bridge).filter(Bridge.id == bridge_id).first()


def update_bridge(
    db: Session,
    bridge: Bridge,
    bridge_data: BridgeUpdate,
) -> Bridge:
    update_data = bridge_data.model_dump(exclude_unset=True)

    for field, value in update_data.items():
        setattr(bridge, field, value)

    db.commit()
    db.refresh(bridge)
    return bridge


def delete_bridge(db: Session, bridge: Bridge) -> None:
    db.delete(bridge)
    db.commit()
