from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.core.security import hash_password
from app.database.models import User
from app.schemas.users import UserCreate, UserUpdate


def create_user(db: Session, user_data: UserCreate) -> User:
    user = User(
        username=user_data.username,
        password_hash=hash_password(user_data.password),
        role=user_data.role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


def get_user_by_id(db: Session, user_id: int) -> User | None:
    return db.query(User).filter(User.id == user_id).first()


def get_user_by_username(db: Session, username: str) -> User | None:
    return db.query(User).filter(User.username == username).first()


def count_users(db: Session) -> int:
    return db.query(User).count()


def get_users(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    search: str | None = None,
    role: str | None = None,
    sort_by: str = "id",
    sort_dir: str = "desc",
) -> list[User]:
    query = db.query(User)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(or_(User.username.ilike(search_pattern)))

    if role:
        query = query.filter(User.role == role)

    sort_columns = {
        "id": User.id,
        "username": User.username,
        "role": User.role,
        "created_at": User.created_at,
    }
    sort_column = sort_columns.get(sort_by, User.id)
    if sort_dir == "asc":
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    return query.offset(skip).limit(limit).all()


def update_user(db: Session, user: User, user_data: UserUpdate) -> User:
    update_data = user_data.model_dump(exclude_unset=True)
    password = update_data.pop("password", None)

    if password:
        user.password_hash = hash_password(password)

    for field, value in update_data.items():
        setattr(user, field, value)

    db.commit()
    db.refresh(user)
    return user


def delete_user(db: Session, user: User) -> None:
    db.delete(user)
    db.commit()
