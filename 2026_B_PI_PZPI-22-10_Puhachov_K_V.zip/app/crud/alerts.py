from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database.models import Alert
from app.schemas.alerts import AlertUpdate


def get_alert_by_id(db: Session, alert_id: int) -> Alert | None:
    return db.query(Alert).filter(Alert.id == alert_id).first()


def get_alerts(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    search: str | None = None,
    bridge_id: int | None = None,
    sensor_id: int | None = None,
    alert_level: str | None = None,
    is_resolved: bool | None = None,
    sort_by: str = "created_at",
    sort_dir: str = "desc",
) -> list[Alert]:
    query = db.query(Alert)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(or_(Alert.message.ilike(search_pattern)))

    if bridge_id:
        query = query.filter(Alert.bridge_id == bridge_id)

    if sensor_id:
        query = query.filter(Alert.sensor_id == sensor_id)

    if alert_level:
        query = query.filter(Alert.alert_level == alert_level)

    if is_resolved is not None:
        query = query.filter(Alert.is_resolved == is_resolved)

    sort_columns = {
        "id": Alert.id,
        "bridge_id": Alert.bridge_id,
        "sensor_id": Alert.sensor_id,
        "alert_level": Alert.alert_level,
        "is_resolved": Alert.is_resolved,
        "created_at": Alert.created_at,
    }
    sort_column = sort_columns.get(sort_by, Alert.created_at)
    if sort_dir == "asc":
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    return query.offset(skip).limit(limit).all()


def update_alert(db: Session, alert: Alert, alert_data: AlertUpdate) -> Alert:
    alert.is_resolved = alert_data.is_resolved
    db.commit()
    db.refresh(alert)
    return alert
