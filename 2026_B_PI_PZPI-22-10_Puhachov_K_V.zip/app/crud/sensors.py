from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database.models import AvailableSensor, Sensor
from app.schemas.sensors import AvailableSensorCreate, SensorCreate, SensorUpdate


def create_sensor(db: Session, sensor_data: SensorCreate) -> Sensor:
    sensor = Sensor(**sensor_data.model_dump())
    db.add(sensor)
    db.commit()
    db.refresh(sensor)
    return sensor


def get_sensor_by_id(db: Session, sensor_id: int) -> Sensor | None:
    return db.query(Sensor).filter(Sensor.id == sensor_id).first()


def get_available_sensor_by_id(
    db: Session,
    available_sensor_id: int,
) -> AvailableSensor | None:
    return (
        db.query(AvailableSensor)
        .filter(AvailableSensor.id == available_sensor_id)
        .first()
    )


def get_available_sensor_by_uid(db: Session, device_uid: str) -> AvailableSensor | None:
    return (
        db.query(AvailableSensor)
        .filter(AvailableSensor.device_uid == device_uid)
        .first()
    )


def get_sensors(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    search: str | None = None,
    bridge_id: int | None = None,
    sensor_type: str | None = None,
    is_active: bool | None = None,
    sort_by: str = "id",
    sort_dir: str = "desc",
) -> list[Sensor]:
    query = db.query(Sensor)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                Sensor.name.ilike(search_pattern),
                Sensor.sensor_type.ilike(search_pattern),
                Sensor.unit.ilike(search_pattern),
            )
        )

    if bridge_id:
        query = query.filter(Sensor.bridge_id == bridge_id)

    if sensor_type:
        query = query.filter(Sensor.sensor_type == sensor_type)

    if is_active is not None:
        query = query.filter(Sensor.is_active == is_active)

    sort_columns = {
        "id": Sensor.id,
        "name": Sensor.name,
        "sensor_type": Sensor.sensor_type,
        "bridge_id": Sensor.bridge_id,
        "is_active": Sensor.is_active,
        "created_at": Sensor.created_at,
    }
    sort_column = sort_columns.get(sort_by, Sensor.id)
    if sort_dir == "asc":
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    return query.offset(skip).limit(limit).all()


def get_available_sensors(
    db: Session,
    skip: int = 0,
    limit: int = 100,
    search: str | None = None,
    sensor_type: str | None = None,
    is_installed: bool | None = None,
    sort_by: str = "discovered_at",
    sort_dir: str = "desc",
) -> list[AvailableSensor]:
    query = db.query(AvailableSensor)

    if search:
        search_pattern = f"%{search}%"
        query = query.filter(
            or_(
                AvailableSensor.device_uid.ilike(search_pattern),
                AvailableSensor.name.ilike(search_pattern),
                AvailableSensor.manufacturer.ilike(search_pattern),
            )
        )

    if sensor_type:
        query = query.filter(AvailableSensor.sensor_type == sensor_type)

    if is_installed is not None:
        query = query.filter(AvailableSensor.is_installed == is_installed)

    sort_columns = {
        "id": AvailableSensor.id,
        "device_uid": AvailableSensor.device_uid,
        "name": AvailableSensor.name,
        "sensor_type": AvailableSensor.sensor_type,
        "manufacturer": AvailableSensor.manufacturer,
        "is_installed": AvailableSensor.is_installed,
        "discovered_at": AvailableSensor.discovered_at,
    }
    sort_column = sort_columns.get(sort_by, AvailableSensor.discovered_at)
    if sort_dir == "asc":
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())

    return query.offset(skip).limit(limit).all()


def create_available_sensor(
    db: Session,
    sensor_data: AvailableSensorCreate,
) -> AvailableSensor:
    available_sensor = AvailableSensor(**sensor_data.model_dump())
    db.add(available_sensor)
    db.commit()
    db.refresh(available_sensor)
    return available_sensor


def update_sensor(db: Session, sensor: Sensor, sensor_data: SensorUpdate) -> Sensor:
    update_data = sensor_data.model_dump(exclude_unset=True)

    for field, value in update_data.items():
        setattr(sensor, field, value)

    db.commit()
    db.refresh(sensor)
    return sensor


def mark_available_sensor_installed(
    db: Session,
    available_sensor: AvailableSensor,
    installed_sensor: Sensor,
) -> AvailableSensor:
    available_sensor.is_installed = True
    available_sensor.installed_sensor_id = installed_sensor.id
    db.commit()
    db.refresh(available_sensor)
    return available_sensor


def mark_available_sensor_uninstalled(
    db: Session,
    available_sensor_id: int,
) -> None:
    available_sensor = get_available_sensor_by_id(
        db=db,
        available_sensor_id=available_sensor_id,
    )
    if available_sensor is None:
        return

    available_sensor.is_installed = False
    available_sensor.installed_sensor_id = None
    db.commit()


def delete_sensor(db: Session, sensor: Sensor) -> None:
    db.delete(sensor)
    db.commit()
