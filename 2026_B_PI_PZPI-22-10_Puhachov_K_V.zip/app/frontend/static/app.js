const app = document.querySelector("#app");

const state = {
  token: localStorage.getItem("bridge_token") || "",
  user: JSON.parse(localStorage.getItem("bridge_user") || "null"),
  authMode: "login",
  view: localStorage.getItem("bridge_view") || "overview",
  data: {
    bridges: [],
    inspectors: [],
    sensors: [],
    availableSensors: [],
    sensorTypes: [],
    alerts: [],
    users: [],
    bridgeProblems: null,
  },
  filters: {
    bridges: { search: "", status: "", sort_by: "id", sort_dir: "desc" },
    inspectors: { search: "", sort_by: "id", sort_dir: "desc" },
    sensors: { search: "", bridge_id: "", sensor_type: "", is_active: "", sort_by: "id", sort_dir: "desc" },
    availableSensors: { search: "", sensor_type: "", is_installed: "false", sort_by: "discovered_at", sort_dir: "desc" },
    alerts: { bridge_id: "", sensor_id: "", alert_level: "", is_resolved: "false", sort_by: "created_at", sort_dir: "desc" },
    users: { search: "", role: "", sort_by: "id", sort_dir: "desc" },
  },
  editing: null,
  problemBridgeId: "",
  chart: { bridge_id: "", sensor_id: "", period: "day", data: null },
  toast: null,
};

const views = [
  { id: "overview", label: "Overview" },
  { id: "bridges", label: "Bridges" },
  { id: "inspectors", label: "Inspectors" },
  { id: "sensors", label: "Sensors" },
  { id: "charts", label: "Charts" },
  { id: "alerts", label: "Alerts" },
  { id: "users", label: "Users", adminOnly: true },
];

function canWrite() {
  return state.user && ["admin", "inspector"].includes(state.user.role);
}

function isAdmin() {
  return state.user && state.user.role === "admin";
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function formatDate(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString();
}

function badge(value, fallback = "") {
  const label = value ?? fallback;
  return `<span class="badge ${escapeHtml(label)}">${escapeHtml(label)}</span>`;
}

function setToast(message, type = "info") {
  state.toast = { message, type };
  renderToast();
  window.clearTimeout(setToast.timer);
  setToast.timer = window.setTimeout(() => {
    state.toast = null;
    renderToast();
  }, 3200);
}

function renderToast() {
  document.querySelector(".toast")?.remove();
  if (!state.toast) return;
  const toast = document.createElement("div");
  toast.className = `toast ${state.toast.type}`;
  toast.textContent = state.toast.message;
  document.body.appendChild(toast);
}

async function api(path, options = {}) {
  const headers = {
    "Accept": "application/json",
    ...(options.headers || {}),
  };

  if (state.token) {
    headers.Authorization = `Bearer ${state.token}`;
  }

  if (options.body && !(options.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
    options.body = JSON.stringify(options.body);
  }

  const response = await fetch(path, { ...options, headers });
  const text = await response.text();
  const payload = text ? JSON.parse(text) : null;

  if (response.status === 401) {
    logout(false);
    throw new Error("Session expired");
  }

  if (!response.ok) {
    const detail = payload?.detail;
    if (Array.isArray(detail)) {
      throw new Error(detail.map((item) => item.msg).join("; "));
    }
    throw new Error(detail || `Request failed: ${response.status}`);
  }

  return payload;
}

function queryString(params) {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== "" && value !== null && value !== undefined) {
      search.set(key, value);
    }
  });
  const text = search.toString();
  return text ? `?${text}` : "";
}

async function login(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  try {
    const payload = await api("/auth/login", {
      method: "POST",
      body: {
        username: form.get("username"),
        password: form.get("password"),
      },
    });
    state.token = payload.access_token;
    state.user = payload.user;
    localStorage.setItem("bridge_token", state.token);
    localStorage.setItem("bridge_user", JSON.stringify(state.user));
    state.view = "overview";
    localStorage.setItem("bridge_view", state.view);
    await bootstrap();
  } catch (error) {
    setToast(error.message, "error");
  }
}

async function register(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  try {
    await api("/auth/register", {
      method: "POST",
      body: {
        username: form.get("username"),
        password: form.get("password"),
      },
    });
    setToast("User created");
    state.authMode = "login";
    renderAuth();
  } catch (error) {
    setToast(error.message, "error");
  }
}

function logout(showMessage = true) {
  state.token = "";
  state.user = null;
  localStorage.removeItem("bridge_token");
  localStorage.removeItem("bridge_user");
  if (showMessage) setToast("Signed out");
  renderAuth();
}

function renderAuth() {
  app.className = "app";
  app.innerHTML = `
    <main class="auth-screen">
      <section class="auth-panel">
        <div class="auth-head">
          <h1>Bridge Monitoring</h1>
          <div class="brand-subtitle">Technical control panel</div>
        </div>
        <div class="auth-tabs">
          <button class="tab-button ${state.authMode === "login" ? "active" : ""}" data-auth-mode="login">Login</button>
          <button class="tab-button ${state.authMode === "register" ? "active" : ""}" data-auth-mode="register">Register</button>
        </div>
        <div class="auth-body">
          ${state.authMode === "login" ? authForm("login") : authForm("register")}
        </div>
      </section>
    </main>
  `;

  app.querySelectorAll("[data-auth-mode]").forEach((button) => {
    button.addEventListener("click", () => {
      state.authMode = button.dataset.authMode;
      renderAuth();
    });
  });

  app.querySelector("#authForm")?.addEventListener("submit", state.authMode === "login" ? login : register);
}

function authForm(mode) {
  return `
    <form id="authForm" class="form-grid">
      <div class="field">
        <label for="username">Username</label>
        <input id="username" name="username" autocomplete="username" required minlength="3">
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="${mode === "login" ? "current-password" : "new-password"}" required minlength="${mode === "login" ? "1" : "6"}">
      </div>
      <button class="button primary" type="submit">${mode === "login" ? "Login" : "Register"}</button>
    </form>
  `;
}

function renderShell() {
  const navItems = views
    .filter((view) => !view.adminOnly || isAdmin())
    .map((view) => `
      <button class="nav-button ${state.view === view.id ? "active" : ""}" data-view="${view.id}">
        <span>${view.label}</span><span>${navMark(view.id)}</span>
      </button>
    `)
    .join("");

  app.className = "app shell";
  app.innerHTML = `
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-mark">BM</div>
        <div>
          <div class="brand-title">Bridge Monitor</div>
          <div class="brand-subtitle">Operations</div>
        </div>
      </div>
      <nav class="nav">${navItems}</nav>
      <div class="user-box">
        <div><strong>${escapeHtml(state.user.username)}</strong></div>
        <div class="user-meta">${escapeHtml(state.user.role)}</div>
        <button class="button ghost" id="logoutButton" type="button">Logout</button>
      </div>
    </aside>
    <main class="content">
      <div id="viewRoot"></div>
    </main>
  `;

  app.querySelectorAll("[data-view]").forEach((button) => {
    button.addEventListener("click", async () => {
      state.view = button.dataset.view;
      state.editing = null;
      localStorage.setItem("bridge_view", state.view);
      await loadViewData();
      renderShell();
      renderView();
    });
  });

  app.querySelector("#logoutButton").addEventListener("click", () => logout());
}

function navMark(id) {
  return {
    overview: "01",
    bridges: "02",
    inspectors: "03",
    sensors: "04",
    charts: "05",
    alerts: "06",
    users: "07",
  }[id] || "";
}

function topbar(title, subtitle, action = "") {
  return `
    <div class="topbar">
      <div class="title-block">
        <h1>${title}</h1>
        <p>${subtitle}</p>
      </div>
      <div class="button-row">${action}</div>
    </div>
  `;
}

function renderView() {
  const root = document.querySelector("#viewRoot");
  if (!root) return;

  const renderer = {
    overview: renderOverview,
    bridges: renderBridges,
    inspectors: renderInspectors,
    sensors: renderSensors,
    charts: renderCharts,
    alerts: renderAlerts,
    users: renderUsers,
  }[state.view] || renderOverview;

  root.innerHTML = renderer();
  bindCommonEvents(root);
  bindViewEvents(root);
  if (state.view === "charts") {
    drawChart();
  }
}

function bindCommonEvents(root) {
  root.querySelectorAll("[data-filter]").forEach((input) => {
    input.addEventListener("input", () => {
      const [scope, key] = input.dataset.filter.split(".");
      state.filters[scope][key] = input.value;
    });
    input.addEventListener("change", async () => {
      const [scope, key] = input.dataset.filter.split(".");
      state.filters[scope][key] = input.value;
      await loadViewData();
      renderShell();
      renderView();
    });
  });

  root.querySelectorAll("[data-filter-submit]").forEach((button) => {
    button.addEventListener("click", async () => {
      await loadViewData();
      renderShell();
      renderView();
    });
  });

  root.querySelectorAll("[data-edit]").forEach((button) => {
    button.addEventListener("click", () => {
      const [scope, id] = button.dataset.edit.split(":");
      state.editing = { scope, id: Number(id) };
      renderView();
    });
  });

  root.querySelectorAll("[data-new]").forEach((button) => {
    button.addEventListener("click", () => {
      state.editing = { scope: button.dataset.new, id: null };
      renderView();
    });
  });

  root.querySelectorAll("[data-cancel-edit]").forEach((button) => {
    button.addEventListener("click", () => {
      state.editing = null;
      renderView();
    });
  });
}

function bindViewEvents(root) {
  root.querySelector("#bridgeForm")?.addEventListener("submit", saveBridge);
  root.querySelector("#inspectorForm")?.addEventListener("submit", saveInspector);
  root.querySelector("#sensorForm")?.addEventListener("submit", saveSensor);
  root.querySelector("#installSensorForm")?.addEventListener("submit", installSensor);
  root.querySelector("#userForm")?.addEventListener("submit", saveUser);

  root.querySelectorAll("[data-delete]").forEach((button) => {
    button.addEventListener("click", async () => {
      const [scope, id] = button.dataset.delete.split(":");
      await deleteItem(scope, Number(id));
    });
  });

  root.querySelectorAll("[data-alert-resolve]").forEach((button) => {
    button.addEventListener("click", async () => {
      const [id, value] = button.dataset.alertResolve.split(":");
      await updateAlert(Number(id), value === "true");
    });
  });

  root.querySelector("[data-seed-available]")?.addEventListener("click", seedAvailableSensors);

  root.querySelectorAll("[data-install-sensor]").forEach((button) => {
    button.addEventListener("click", () => {
      state.editing = { scope: "availableSensors", id: Number(button.dataset.installSensor) };
      renderView();
    });
  });

  root.querySelectorAll("[data-bridge-problems]").forEach((button) => {
    button.addEventListener("click", async () => {
      state.problemBridgeId = button.dataset.bridgeProblems;
      await loadBridgeProblems();
      renderView();
    });
  });

  root.querySelector("#sensorType")?.addEventListener("change", (event) => {
    const type = state.data.sensorTypes.find((item) => item.code === event.target.value);
    if (!type) return;
    const unit = root.querySelector("[name='unit']");
    const minValue = root.querySelector("[name='min_value']");
    const maxValue = root.querySelector("[name='max_value']");
    if (unit && !unit.value) unit.value = type.default_unit;
    if (minValue && !minValue.value) minValue.value = type.default_min;
    if (maxValue && !maxValue.value) maxValue.value = type.default_max;
  });

  root.querySelector("#chartBridge")?.addEventListener("change", async (event) => {
    state.chart.bridge_id = event.target.value;
    const sensors = state.data.sensors.filter((sensor) => String(sensor.bridge_id) === String(state.chart.bridge_id));
    state.chart.sensor_id = sensors[0]?.id ? String(sensors[0].id) : "";
    await loadChart();
    renderView();
  });

  root.querySelector("#chartSensor")?.addEventListener("change", async (event) => {
    state.chart.sensor_id = event.target.value;
    await loadChart();
    renderView();
  });

  root.querySelectorAll("[data-period]").forEach((button) => {
    button.addEventListener("click", async () => {
      state.chart.period = button.dataset.period;
      await loadChart();
      renderView();
    });
  });
}

async function loadBaseData() {
  const [bridges, sensors, inspectors, sensorTypes, alerts] = await Promise.all([
    api(`/bridges${queryString({ limit: 200 })}`),
    api(`/sensors${queryString({ limit: 200 })}`),
    api(`/inspectors${queryString({ limit: 200 })}`),
    api("/sensors/types"),
    api(`/alerts${queryString({ limit: 100 })}`),
  ]);
  state.data.bridges = bridges;
  state.data.sensors = sensors;
  state.data.inspectors = inspectors;
  state.data.sensorTypes = sensorTypes;
  state.data.alerts = alerts;

  const selectedBridgeExists = bridges.some((bridge) => String(bridge.id) === String(state.problemBridgeId));
  const firstProblemBridge = bridges.find((bridge) => bridge.status !== "normal");
  if (!selectedBridgeExists) {
    state.problemBridgeId = firstProblemBridge ? String(firstProblemBridge.id) : "";
  }
  if (state.problemBridgeId) {
    await loadBridgeProblems();
  } else {
    state.data.bridgeProblems = null;
  }
}

async function loadViewData() {
  if (!state.token) return;

  if (state.view === "overview") {
    await loadBaseData();
    return;
  }

  if (state.view === "bridges") {
    state.data.bridges = await api(`/bridges${queryString({ limit: 200, ...state.filters.bridges })}`);
    if (state.problemBridgeId) {
      await loadBridgeProblems();
    }
  }

  if (state.view === "inspectors") {
    state.data.inspectors = await api(`/inspectors${queryString({ limit: 200, ...state.filters.inspectors })}`);
  }

  if (state.view === "sensors") {
    const params = { limit: 200, ...state.filters.sensors };
    if (params.is_active === "all") params.is_active = "";
    const availableParams = { limit: 200, ...state.filters.availableSensors };
    if (availableParams.is_installed === "all") availableParams.is_installed = "";
    const [bridges, sensors, availableSensors, inspectors, sensorTypes] = await Promise.all([
      api(`/bridges${queryString({ limit: 200 })}`),
      api(`/sensors${queryString(params)}`),
      api(`/sensors/available${queryString(availableParams)}`),
      api(`/inspectors${queryString({ limit: 200 })}`),
      api("/sensors/types"),
    ]);
    state.data.bridges = bridges;
    state.data.sensors = sensors;
    state.data.availableSensors = availableSensors;
    state.data.inspectors = inspectors;
    state.data.sensorTypes = sensorTypes;
  }

  if (state.view === "charts") {
    const [bridges, sensors] = await Promise.all([
      api(`/bridges${queryString({ limit: 200 })}`),
      api(`/sensors${queryString({ limit: 200 })}`),
    ]);
    state.data.bridges = bridges;
    state.data.sensors = sensors;
    if (!state.chart.bridge_id && bridges[0]) state.chart.bridge_id = String(bridges[0].id);
    const bridgeSensors = sensors.filter((sensor) => String(sensor.bridge_id) === String(state.chart.bridge_id));
    if (!state.chart.sensor_id && bridgeSensors[0]) state.chart.sensor_id = String(bridgeSensors[0].id);
    await loadChart();
  }

  if (state.view === "alerts") {
    const params = { limit: 200, ...state.filters.alerts };
    if (params.is_resolved === "all") params.is_resolved = "";
    const [bridges, sensors, inspectors, alerts] = await Promise.all([
      api(`/bridges${queryString({ limit: 200 })}`),
      api(`/sensors${queryString({ limit: 200 })}`),
      api(`/inspectors${queryString({ limit: 200 })}`),
      api(`/alerts${queryString(params)}`),
    ]);
    state.data.bridges = bridges;
    state.data.sensors = sensors;
    state.data.inspectors = inspectors;
    state.data.alerts = alerts;
  }

  if (state.view === "users" && isAdmin()) {
    state.data.users = await api(`/auth/users${queryString({ limit: 200, ...state.filters.users })}`);
  }
}

async function loadBridgeProblems() {
  if (!state.problemBridgeId) {
    state.data.bridgeProblems = null;
    return;
  }
  state.data.bridgeProblems = await api(`/bridges/${state.problemBridgeId}/problems`);
}

async function loadChart() {
  if (!state.chart.sensor_id) {
    state.chart.data = null;
    return;
  }
  state.chart.data = await api(`/readings/sensors/${state.chart.sensor_id}/chart${queryString({ period: state.chart.period })}`);
}

async function bootstrap() {
  if (!state.token) {
    renderAuth();
    return;
  }

  try {
    state.user = await api("/auth/me");
    localStorage.setItem("bridge_user", JSON.stringify(state.user));
    if (state.view === "users" && !isAdmin()) state.view = "overview";
    await loadViewData();
    renderShell();
    renderView();
  } catch (error) {
    setToast(error.message, "error");
  }
}

function renderOverview() {
  const bridges = state.data.bridges;
  const sensors = state.data.sensors;
  const alerts = state.data.alerts;
  const openAlerts = alerts.filter((alert) => !alert.is_resolved);
  const dangerBridges = bridges.filter((bridge) => bridge.status === "danger").length;

  return `
    ${topbar("Overview", "System state", `<button class="button" data-filter-submit type="button">Refresh</button>`)}
    <section class="metric-grid">
      ${metric("Bridges", bridges.length)}
      ${metric("Active sensors", sensors.filter((sensor) => sensor.is_active).length)}
      ${metric("Open alerts", openAlerts.length)}
      ${metric("Danger bridges", dangerBridges)}
    </section>
    <section class="split-grid">
      <div class="stack">
        <div class="panel">
          <div class="panel-head"><h2>Bridge Status</h2></div>
          <div class="table-wrap">${bridgeTable(bridges.slice(0, 8), "problems")}</div>
        </div>
        ${problemPanel()}
      </div>
      <div class="panel">
        <div class="panel-head"><h2>Open Alerts</h2></div>
        <div class="table-wrap">${alertTable(openAlerts.slice(0, 8), false)}</div>
      </div>
    </section>
  `;
}

function metric(label, value) {
  return `
    <div class="metric">
      <div class="metric-label">${label}</div>
      <div class="metric-value">${escapeHtml(value)}</div>
    </div>
  `;
}

function renderBridges() {
  const edit = state.editing?.scope === "bridges"
    ? bridgeForm(state.editing.id ? state.data.bridges.find((item) => item.id === state.editing.id) : null)
    : "";
  return `
    ${topbar("Bridges", "Registry", canWrite() ? `<button class="button primary" data-new="bridges" type="button">Add Bridge</button>` : "")}
    ${bridgeToolbar()}
    <section class="split-grid">
      <div class="panel">
        <div class="panel-head"><h2>Bridges</h2></div>
        <div class="table-wrap">${bridgeTable(state.data.bridges, "manage")}</div>
      </div>
      ${edit}
    </section>
    ${problemPanel()}
  `;
}

function bridgeToolbar() {
  const filters = state.filters.bridges;
  return `
    <div class="toolbar">
      ${field("Search", `<input data-filter="bridges.search" value="${escapeHtml(filters.search)}">`)}
      ${field("Status", select("bridges.status", filters.status, [["", "All"], ["normal", "normal"], ["warning", "warning"], ["danger", "danger"]]))}
      ${field("Sort by", select("bridges.sort_by", filters.sort_by, [["id", "id"], ["name", "name"], ["location", "location"], ["status", "status"], ["created_at", "created_at"]]))}
      ${field("Direction", select("bridges.sort_dir", filters.sort_dir, [["desc", "desc"], ["asc", "asc"]]))}
      <button class="button" data-filter-submit type="button">Apply</button>
    </div>
  `;
}

function bridgeTable(items, actions) {
  if (!items.length) return emptyState();
  return `
    <table>
      <thead><tr><th>ID</th><th>Name</th><th>Location</th><th>Status</th><th>Created</th>${actions ? "<th>Actions</th>" : ""}</tr></thead>
      <tbody>
        ${items.map((bridge) => `
          <tr>
            <td>${bridge.id}</td>
            <td><strong>${escapeHtml(bridge.name)}</strong><div class="muted">${escapeHtml(bridge.description || "")}</div></td>
            <td>${escapeHtml(bridge.location)}</td>
            <td>${badge(bridge.status)}</td>
            <td>${formatDate(bridge.created_at)}</td>
            ${actions ? bridgeActions(bridge, actions) : ""}
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function bridgeActions(bridge, mode) {
  const problemButton = bridge.status !== "normal"
    ? `<button class="button" data-bridge-problems="${bridge.id}" type="button">Reason</button>`
    : "";
  const manageButtons = mode === "manage" ? `
    ${canWrite() ? `<button class="button" data-edit="bridges:${bridge.id}" type="button">Edit</button>` : ""}
    ${isAdmin() ? `<button class="button danger" data-delete="bridges:${bridge.id}" type="button">Delete</button>` : ""}
  ` : "";

  return `
    <td>
      <div class="cell-actions">
        ${problemButton}
        ${manageButtons}
      </div>
    </td>
  `;
}

function problemPanel() {
  const problems = state.data.bridgeProblems;
  if (!problems) return "";

  return `
    <section class="panel problem-panel">
      <div class="panel-head">
        <h2>Problem Reason</h2>
        <button class="button ghost" type="button" data-bridge-problems="">Close</button>
      </div>
      <div class="panel-body">
        <p class="muted">${escapeHtml(problems.reason)}</p>
        <div class="table-wrap">${problemTable(problems.open_alerts)}</div>
      </div>
    </section>
  `;
}

function problemTable(items) {
  if (!items.length) return emptyState();
  return `
    <table>
      <thead><tr><th>Level</th><th>Sensor</th><th>Responsible</th><th>Value</th><th>Why</th><th>Created</th></tr></thead>
      <tbody>
        ${items.map((item) => `
          <tr>
            <td>${badge(item.alert_level)}</td>
            <td>
              <strong>${escapeHtml(item.sensor.name)}</strong>
              <div class="muted">${escapeHtml(item.sensor.manufacturer || "")}</div>
              <div class="muted">${escapeHtml(item.sensor.description_uk || "")}</div>
            </td>
            <td>
              ${escapeHtml(item.sensor.responsible_inspector_name || "Not assigned")}
              <div class="muted">${escapeHtml(item.sensor.installed_by || "")}</div>
            </td>
            <td>${item.value} ${escapeHtml(item.sensor.unit)}</td>
            <td>${escapeHtml(item.message)}</td>
            <td>${formatDate(item.created_at)}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function bridgeForm(item) {
  return `
    <div class="panel">
      <div class="panel-head">
        <h2>${item ? "Edit Bridge" : "Add Bridge"}</h2>
        <button class="button ghost" data-cancel-edit type="button">Close</button>
      </div>
      <div class="panel-body">
        <form id="bridgeForm" class="form-grid">
          <input type="hidden" name="id" value="${item?.id || ""}">
          ${field("Name", `<input name="name" value="${escapeHtml(item?.name || "")}" required minlength="2">`)}
          ${field("Location", `<input name="location" value="${escapeHtml(item?.location || "")}" required minlength="2">`)}
          ${field("Status", rawSelect("status", item?.status || "normal", [["normal", "normal"], ["warning", "warning"], ["danger", "danger"]]))}
          ${field("Description", `<textarea name="description">${escapeHtml(item?.description || "")}</textarea>`)}
          <button class="button primary" type="submit">Save</button>
        </form>
      </div>
    </div>
  `;
}

async function saveBridge(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  const id = data.id;
  delete data.id;
  try {
    await api(id ? `/bridges/${id}` : "/bridges", { method: id ? "PUT" : "POST", body: data });
    state.editing = null;
    await loadViewData();
    renderShell();
    renderView();
    setToast("Bridge saved");
  } catch (error) {
    setToast(error.message, "error");
  }
}

function renderInspectors() {
  const edit = state.editing?.scope === "inspectors"
    ? inspectorForm(state.editing.id ? state.data.inspectors.find((item) => item.id === state.editing.id) : null)
    : "";
  return `
    ${topbar("Inspectors", "Personnel", isAdmin() ? `<button class="button primary" data-new="inspectors" type="button">Add Inspector</button>` : "")}
    ${inspectorToolbar()}
    <section class="split-grid">
      <div class="panel">
        <div class="panel-head"><h2>Inspectors</h2></div>
        <div class="table-wrap">${inspectorTable(state.data.inspectors)}</div>
      </div>
      ${edit}
    </section>
  `;
}

function inspectorToolbar() {
  const filters = state.filters.inspectors;
  return `
    <div class="toolbar compact">
      ${field("Search", `<input data-filter="inspectors.search" value="${escapeHtml(filters.search)}">`)}
      ${field("Sort by", select("inspectors.sort_by", filters.sort_by, [["id", "id"], ["full_name", "full_name"], ["email", "email"], ["position", "position"], ["created_at", "created_at"]]))}
      ${field("Direction", select("inspectors.sort_dir", filters.sort_dir, [["desc", "desc"], ["asc", "asc"]]))}
      <button class="button" data-filter-submit type="button">Apply</button>
    </div>
  `;
}

function inspectorTable(items) {
  if (!items.length) return emptyState();
  return `
    <table>
      <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Position</th><th>Created</th>${isAdmin() ? "<th>Actions</th>" : ""}</tr></thead>
      <tbody>
        ${items.map((item) => `
          <tr>
            <td>${item.id}</td>
            <td><strong>${escapeHtml(item.full_name)}</strong></td>
            <td>${escapeHtml(item.email)}</td>
            <td>${escapeHtml(item.phone || "")}</td>
            <td>${escapeHtml(item.position || "")}</td>
            <td>${formatDate(item.created_at)}</td>
            ${isAdmin() ? rowActions("inspectors", item.id, true, true) : ""}
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function inspectorForm(item) {
  return `
    <div class="panel">
      <div class="panel-head">
        <h2>${item ? "Edit Inspector" : "Add Inspector"}</h2>
        <button class="button ghost" data-cancel-edit type="button">Close</button>
      </div>
      <div class="panel-body">
        <form id="inspectorForm" class="form-grid">
          <input type="hidden" name="id" value="${item?.id || ""}">
          ${field("Full name", `<input name="full_name" value="${escapeHtml(item?.full_name || "")}" required minlength="2">`)}
          ${field("Email", `<input name="email" type="email" value="${escapeHtml(item?.email || "")}" required>`)}
          ${field("Phone", `<input name="phone" value="${escapeHtml(item?.phone || "")}">`)}
          ${field("Position", `<input name="position" value="${escapeHtml(item?.position || "")}">`)}
          <button class="button primary" type="submit">Save</button>
        </form>
      </div>
    </div>
  `;
}

async function saveInspector(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  const id = data.id;
  delete data.id;
  try {
    await api(id ? `/inspectors/${id}` : "/inspectors", { method: id ? "PUT" : "POST", body: data });
    state.editing = null;
    await loadViewData();
    renderShell();
    renderView();
    setToast("Inspector saved");
  } catch (error) {
    setToast(error.message, "error");
  }
}

function renderSensors() {
  const editInstalled = state.editing?.scope === "sensors"
    ? sensorForm(state.editing.id ? state.data.sensors.find((item) => item.id === state.editing.id) : null)
    : "";
  const installForm = state.editing?.scope === "availableSensors"
    ? installSensorForm(state.data.availableSensors.find((item) => item.id === state.editing.id))
    : "";
  return `
    ${topbar("Sensors", "Installed and discovered devices", isAdmin() ? `<button class="button primary" data-seed-available type="button">Scan Test Sensors</button>` : "")}
    ${sensorToolbar()}
    <section class="split-grid">
      <div class="panel">
        <div class="panel-head"><h2>Installed Sensors</h2></div>
        <div class="table-wrap">${sensorTable(state.data.sensors)}</div>
      </div>
      ${editInstalled}
    </section>
    ${availableSensorToolbar()}
    <section class="split-grid">
      <div class="panel">
        <div class="panel-head"><h2>Available Sensors</h2></div>
        <div class="table-wrap">${availableSensorTable(state.data.availableSensors)}</div>
      </div>
      ${installForm}
    </section>
  `;
}

function sensorToolbar() {
  const filters = state.filters.sensors;
  const bridgeOptions = [["", "All"], ...state.data.bridges.map((bridge) => [bridge.id, bridge.name])];
  const typeOptions = [["", "All"], ...state.data.sensorTypes.map((type) => [type.code, type.code])];
  return `
    <div class="toolbar">
      ${field("Search", `<input data-filter="sensors.search" value="${escapeHtml(filters.search)}">`)}
      ${field("Bridge", select("sensors.bridge_id", filters.bridge_id, bridgeOptions))}
      ${field("Type", select("sensors.sensor_type", filters.sensor_type, typeOptions))}
      ${field("Active", select("sensors.is_active", filters.is_active || "all", [["all", "All"], ["true", "true"], ["false", "false"]]))}
      ${field("Sort", select("sensors.sort_by", filters.sort_by, [["id", "id"], ["name", "name"], ["sensor_type", "sensor_type"], ["bridge_id", "bridge_id"], ["is_active", "is_active"], ["created_at", "created_at"]]))}
      <button class="button" data-filter-submit type="button">Apply</button>
    </div>
  `;
}

function sensorTable(items) {
  if (!items.length) return emptyState();
  return `
    <table>
      <thead><tr><th>ID</th><th>Name</th><th>Bridge</th><th>Manufacturer</th><th>Responsible</th><th>Limits</th><th>Active</th><th>Actions</th></tr></thead>
      <tbody>
        ${items.map((sensor) => `
          <tr>
            <td>${sensor.id}</td>
            <td><strong>${escapeHtml(sensor.name)}</strong><div class="muted">${escapeHtml(sensor.sensor_type)}</div></td>
            <td>${escapeHtml(bridgeName(sensor.bridge_id))}</td>
            <td>${escapeHtml(sensor.manufacturer || "")}</td>
            <td>${escapeHtml(inspectorName(sensor.responsible_inspector_id) || "Not assigned")}<div class="muted">${escapeHtml(sensor.installed_by || "")}</div></td>
            <td>${sensor.min_value} - ${sensor.max_value} ${escapeHtml(sensor.unit)}</td>
            <td>${sensor.is_active ? badge("active") : badge("inactive")}</td>
            ${rowActions("sensors", sensor.id, canWrite(), isAdmin())}
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function sensorForm(item) {
  const bridgeOptions = state.data.bridges.map((bridge) => [bridge.id, bridge.name]);
  const inspectorOptions = [["", "Not assigned"], ...state.data.inspectors.map((inspector) => [inspector.id, inspector.full_name])];
  return `
    <div class="panel">
      <div class="panel-head">
        <h2>Edit Installed Sensor</h2>
        <button class="button ghost" data-cancel-edit type="button">Close</button>
      </div>
      <div class="panel-body">
        <form id="sensorForm" class="form-grid">
          <input type="hidden" name="id" value="${item?.id || ""}">
          <div class="muted"><strong>${escapeHtml(item?.name || "")}</strong><br>${escapeHtml(item?.manufacturer || "")}</div>
          ${field("Bridge", rawSelect("bridge_id", item?.bridge_id || bridgeOptions[0]?.[0] || "", bridgeOptions))}
          ${field("Responsible", rawSelect("responsible_inspector_id", item?.responsible_inspector_id || "", inspectorOptions))}
          ${field("Installed by", `<input name="installed_by" value="${escapeHtml(item?.installed_by || "")}">`)}
          ${field("Active", rawSelect("is_active", String(item?.is_active ?? true), [["true", "true"], ["false", "false"]]))}
          ${field("Опис датчика", `<textarea name="description_uk">${escapeHtml(item?.description_uk || "")}</textarea>`)}
          <button class="button primary" type="submit">Save</button>
        </form>
      </div>
    </div>
  `;
}

async function saveSensor(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  const id = data.id;
  delete data.id;
  data.bridge_id = Number(data.bridge_id);
  data.responsible_inspector_id = data.responsible_inspector_id ? Number(data.responsible_inspector_id) : null;
  data.is_active = data.is_active === "true";
  try {
    await api(`/sensors/${id}`, { method: "PUT", body: data });
    state.editing = null;
    await loadViewData();
    renderShell();
    renderView();
    setToast("Sensor saved");
  } catch (error) {
    setToast(error.message, "error");
  }
}

function availableSensorToolbar() {
  const filters = state.filters.availableSensors;
  const typeOptions = [["", "All"], ...state.data.sensorTypes.map((type) => [type.code, type.code])];
  return `
    <div class="toolbar compact">
      ${field("Available search", `<input data-filter="availableSensors.search" value="${escapeHtml(filters.search)}">`)}
      ${field("Type", select("availableSensors.sensor_type", filters.sensor_type, typeOptions))}
      ${field("Installed", select("availableSensors.is_installed", filters.is_installed || "false", [["all", "All"], ["false", "Available"], ["true", "Installed"]]))}
      <button class="button" data-filter-submit type="button">Apply</button>
    </div>
  `;
}

function availableSensorTable(items) {
  if (!items.length) return emptyState();
  return `
    <table>
      <thead><tr><th>UID</th><th>Name</th><th>Manufacturer</th><th>Limits</th><th>Status</th><th>Description</th><th>Actions</th></tr></thead>
      <tbody>
        ${items.map((sensor) => `
          <tr>
            <td>${escapeHtml(sensor.device_uid)}</td>
            <td><strong>${escapeHtml(sensor.name)}</strong><div class="muted">${escapeHtml(sensor.sensor_type)}</div></td>
            <td>${escapeHtml(sensor.manufacturer)}</td>
            <td>${sensor.min_value} - ${sensor.max_value} ${escapeHtml(sensor.unit)}</td>
            <td>${sensor.is_installed ? badge("installed") : badge("available")}</td>
            <td>${escapeHtml(sensor.description_uk || "")}</td>
            <td>
              <div class="cell-actions">
                ${sensor.is_installed ? "" : `<button class="button" data-install-sensor="${sensor.id}" type="button">Install</button>`}
              </div>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function installSensorForm(item) {
  if (!item) return "";
  const bridgeOptions = state.data.bridges.map((bridge) => [bridge.id, bridge.name]);
  const inspectorOptions = [["", "Not assigned"], ...state.data.inspectors.map((inspector) => [inspector.id, inspector.full_name])];
  return `
    <div class="panel">
      <div class="panel-head">
        <h2>Install Sensor</h2>
        <button class="button ghost" data-cancel-edit type="button">Close</button>
      </div>
      <div class="panel-body">
        <form id="installSensorForm" class="form-grid">
          <input type="hidden" name="available_sensor_id" value="${item.id}">
          <div class="muted"><strong>${escapeHtml(item.name)}</strong><br>${escapeHtml(item.manufacturer)} · ${escapeHtml(item.device_uid)}</div>
          ${field("Bridge", rawSelect("bridge_id", bridgeOptions[0]?.[0] || "", bridgeOptions))}
          ${field("Responsible", rawSelect("responsible_inspector_id", "", inspectorOptions))}
          ${field("Installed by", `<input name="installed_by" value="${escapeHtml(item.installed_by || "")}">`)}
          <button class="button primary" type="submit">Install</button>
        </form>
      </div>
    </div>
  `;
}

async function installSensor(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  const id = data.available_sensor_id;
  delete data.available_sensor_id;
  data.bridge_id = Number(data.bridge_id);
  data.responsible_inspector_id = data.responsible_inspector_id ? Number(data.responsible_inspector_id) : null;
  try {
    await api(`/sensors/available/${id}/install`, { method: "POST", body: data });
    state.editing = null;
    await loadViewData();
    renderShell();
    renderView();
    setToast("Sensor installed");
  } catch (error) {
    setToast(error.message, "error");
  }
}

async function seedAvailableSensors() {
  try {
    await api("/sensors/available/seed", { method: "POST" });
    await loadViewData();
    renderShell();
    renderView();
    setToast("Test sensors discovered");
  } catch (error) {
    setToast(error.message, "error");
  }
}

function renderCharts() {
  const bridgeSensors = state.data.sensors.filter((sensor) => String(sensor.bridge_id) === String(state.chart.bridge_id));
  const chart = state.chart.data;
  const selectedSensor = state.data.sensors.find((sensor) => String(sensor.id) === String(state.chart.sensor_id));
  return `
    ${topbar("Charts", "Sensor history")}
    <section class="panel chart-panel">
      <div class="panel-body">
        <div class="chart-controls">
          ${field("Bridge", `<select id="chartBridge">${options(state.data.bridges.map((bridge) => [bridge.id, bridge.name]), state.chart.bridge_id)}</select>`)}
          ${field("Sensor", `<select id="chartSensor">${options(bridgeSensors.map((sensor) => [sensor.id, sensor.name]), state.chart.sensor_id)}</select>`)}
          <div class="field">
            <label>Period</label>
            <div class="periods">
              ${["day", "week", "month"].map((period) => `<button class="period-button ${state.chart.period === period ? "active" : ""}" data-period="${period}" type="button">${period}</button>`).join("")}
            </div>
          </div>
        </div>
        <div class="chart-wrap"><canvas id="chartCanvas"></canvas></div>
        <section class="metric-grid">
          ${metric("Points", chart?.summary?.count ?? 0)}
          ${metric("Min", chart?.summary?.min_value ?? "-")}
          ${metric("Avg", chart?.summary?.avg_value !== null && chart?.summary?.avg_value !== undefined ? Number(chart.summary.avg_value).toFixed(2) : "-")}
          ${metric("Max", chart?.summary?.max_value ?? "-")}
        </section>
        <div class="table-wrap">${readingHistoryTable(chart?.points || [], selectedSensor)}</div>
      </div>
    </section>
  `;
}

function readingHistoryTable(points, sensor) {
  if (!points.length) return emptyState();
  return `
    <table>
      <thead><tr><th>Recorded</th><th>Value</th><th>Danger level</th><th>Allowed range</th></tr></thead>
      <tbody>
        ${points.slice().reverse().map((point) => `
          <tr>
            <td>${formatDate(point.recorded_at)}</td>
            <td>${point.value} ${escapeHtml(sensor?.unit || "")}</td>
            <td>${badge(readingLevel(sensor, Number(point.value)))}</td>
            <td>${sensor ? `${sensor.min_value} - ${sensor.max_value} ${escapeHtml(sensor.unit)}` : ""}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function readingLevel(sensor, value) {
  if (!sensor) return "normal";
  if (value >= sensor.min_value && value <= sensor.max_value) return "normal";
  const safeRange = Math.max(sensor.max_value - sensor.min_value, 1);
  const distance = value < sensor.min_value ? sensor.min_value - value : value - sensor.max_value;
  return distance / safeRange >= 0.2 ? "danger" : "warning";
}

function drawChart() {
  const canvas = document.querySelector("#chartCanvas");
  if (!canvas) return;
  const rect = canvas.parentElement.getBoundingClientRect();
  const ratio = window.devicePixelRatio || 1;
  canvas.width = Math.floor(rect.width * ratio);
  canvas.height = Math.floor(rect.height * ratio);
  const ctx = canvas.getContext("2d");
  ctx.scale(ratio, ratio);
  ctx.clearRect(0, 0, rect.width, rect.height);

  const points = state.chart.data?.points || [];
  const padding = { top: 22, right: 24, bottom: 38, left: 54 };
  const width = rect.width - padding.left - padding.right;
  const height = rect.height - padding.top - padding.bottom;

  ctx.strokeStyle = "#d8dee6";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padding.left, padding.top);
  ctx.lineTo(padding.left, padding.top + height);
  ctx.lineTo(padding.left + width, padding.top + height);
  ctx.stroke();

  if (!points.length) {
    ctx.fillStyle = "#64707d";
    ctx.textAlign = "center";
    ctx.fillText("No data", rect.width / 2, rect.height / 2);
    return;
  }

  const values = points.map((point) => Number(point.value));
  let min = Math.min(...values);
  let max = Math.max(...values);
  if (min === max) {
    min -= 1;
    max += 1;
  }

  const x = (index) => padding.left + (points.length === 1 ? width / 2 : (index / (points.length - 1)) * width);
  const y = (value) => padding.top + height - ((value - min) / (max - min)) * height;

  ctx.strokeStyle = "#2868c7";
  ctx.lineWidth = 2;
  ctx.beginPath();
  points.forEach((point, index) => {
    const px = x(index);
    const py = y(Number(point.value));
    if (index === 0) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  });
  ctx.stroke();

  ctx.fillStyle = "#2868c7";
  points.forEach((point, index) => {
    ctx.beginPath();
    ctx.arc(x(index), y(Number(point.value)), 3, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.fillStyle = "#64707d";
  ctx.textAlign = "right";
  ctx.fillText(max.toFixed(2), padding.left - 8, padding.top + 5);
  ctx.fillText(min.toFixed(2), padding.left - 8, padding.top + height);
}

window.addEventListener("resize", () => {
  if (state.view === "charts") drawChart();
});

function renderAlerts() {
  return `
    ${topbar("Alerts", "Emergency messages", `<button class="button" data-filter-submit type="button">Refresh</button>`)}
    ${alertToolbar()}
    <section class="panel">
      <div class="panel-head"><h2>Alerts</h2></div>
      <div class="table-wrap">${alertTable(state.data.alerts, true)}</div>
    </section>
  `;
}

function alertToolbar() {
  const filters = state.filters.alerts;
  const bridgeOptions = [["", "All"], ...state.data.bridges.map((bridge) => [bridge.id, bridge.name])];
  const sensorOptions = [["", "All"], ...state.data.sensors.map((sensor) => [sensor.id, sensor.name])];
  return `
    <div class="toolbar">
      ${field("Bridge", select("alerts.bridge_id", filters.bridge_id, bridgeOptions))}
      ${field("Sensor", select("alerts.sensor_id", filters.sensor_id, sensorOptions))}
      ${field("Level", select("alerts.alert_level", filters.alert_level, [["", "All"], ["warning", "warning"], ["danger", "danger"]]))}
      ${field("State", select("alerts.is_resolved", filters.is_resolved || "all", [["all", "All"], ["false", "open"], ["true", "resolved"]]))}
      ${field("Sort", select("alerts.sort_by", filters.sort_by, [["created_at", "created_at"], ["alert_level", "alert_level"], ["is_resolved", "is_resolved"]]))}
      <button class="button" data-filter-submit type="button">Apply</button>
    </div>
  `;
}

function alertTable(items, actions) {
  if (!items.length) return emptyState();
  return `
    <table>
      <thead><tr><th>ID</th><th>Bridge</th><th>Sensor</th><th>Responsible</th><th>Level</th><th>Value</th><th>State</th><th>Created</th>${actions ? "<th>Actions</th>" : ""}</tr></thead>
      <tbody>
        ${items.map((alert) => {
          const sensor = state.data.sensors.find((item) => item.id === alert.sensor_id);
          return `
            <tr>
              <td>${alert.id}</td>
              <td>${escapeHtml(bridgeName(alert.bridge_id))}</td>
              <td>${escapeHtml(sensorName(alert.sensor_id))}<div class="muted">${escapeHtml(sensor?.manufacturer || "")}</div><div class="muted">${escapeHtml(alert.message)}</div></td>
              <td>${escapeHtml(inspectorName(sensor?.responsible_inspector_id) || "Not assigned")}<div class="muted">${escapeHtml(sensor?.installed_by || "")}</div></td>
              <td>${badge(alert.alert_level)}</td>
              <td>${alert.value}</td>
              <td>${alert.is_resolved ? badge("resolved") : badge("open")}</td>
              <td>${formatDate(alert.created_at)}</td>
              ${actions ? alertActions(alert) : ""}
            </tr>
          `;
        }).join("")}
      </tbody>
    </table>
  `;
}

function alertActions(alert) {
  if (!canWrite()) return "<td></td>";
  return `
    <td>
      <div class="cell-actions">
        <button class="button" data-alert-resolve="${alert.id}:${!alert.is_resolved}" type="button">${alert.is_resolved ? "Open" : "Resolve"}</button>
      </div>
    </td>
  `;
}

async function updateAlert(id, isResolved) {
  try {
    await api(`/alerts/${id}`, { method: "PUT", body: { is_resolved: isResolved } });
    await loadViewData();
    renderShell();
    renderView();
    setToast("Alert updated");
  } catch (error) {
    setToast(error.message, "error");
  }
}

function renderUsers() {
  if (!isAdmin()) return "";
  const edit = state.editing?.scope === "users"
    ? userForm(state.editing.id ? state.data.users.find((item) => item.id === state.editing.id) : null)
    : "";
  return `
    ${topbar("Users", "Access", `<button class="button primary" data-new="users" type="button">Add User</button>`)}
    ${userToolbar()}
    <section class="split-grid">
      <div class="panel">
        <div class="panel-head"><h2>Users</h2></div>
        <div class="table-wrap">${userTable(state.data.users)}</div>
      </div>
      ${edit}
    </section>
  `;
}

function userToolbar() {
  const filters = state.filters.users;
  return `
    <div class="toolbar compact">
      ${field("Search", `<input data-filter="users.search" value="${escapeHtml(filters.search)}">`)}
      ${field("Role", select("users.role", filters.role, [["", "All"], ["admin", "admin"], ["inspector", "inspector"], ["user", "user"]]))}
      ${field("Sort", select("users.sort_by", filters.sort_by, [["id", "id"], ["username", "username"], ["role", "role"], ["created_at", "created_at"]]))}
      <button class="button" data-filter-submit type="button">Apply</button>
    </div>
  `;
}

function userTable(items) {
  if (!items.length) return emptyState();
  return `
    <table>
      <thead><tr><th>ID</th><th>Username</th><th>Role</th><th>Created</th><th>Actions</th></tr></thead>
      <tbody>
        ${items.map((user) => `
          <tr>
            <td>${user.id}</td>
            <td><strong>${escapeHtml(user.username)}</strong></td>
            <td>${badge(user.role)}</td>
            <td>${formatDate(user.created_at)}</td>
            ${rowActions("users", user.id, true, user.id !== state.user.id)}
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function userForm(item) {
  return `
    <div class="panel">
      <div class="panel-head">
        <h2>${item ? "Edit User" : "Add User"}</h2>
        <button class="button ghost" data-cancel-edit type="button">Close</button>
      </div>
      <div class="panel-body">
        <form id="userForm" class="form-grid">
          <input type="hidden" name="id" value="${item?.id || ""}">
          ${field("Username", `<input name="username" value="${escapeHtml(item?.username || "")}" required minlength="3">`)}
          ${field("Password", `<input name="password" type="password" ${item ? "" : "required"} minlength="6">`)}
          ${field("Role", rawSelect("role", item?.role || "user", [["admin", "admin"], ["inspector", "inspector"], ["user", "user"]]))}
          <button class="button primary" type="submit">Save</button>
        </form>
      </div>
    </div>
  `;
}

async function saveUser(event) {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.currentTarget).entries());
  const id = data.id;
  delete data.id;
  if (!data.password) delete data.password;
  try {
    await api(id ? `/auth/users/${id}` : "/auth/users", { method: id ? "PUT" : "POST", body: data });
    state.editing = null;
    await loadViewData();
    renderShell();
    renderView();
    setToast("User saved");
  } catch (error) {
    setToast(error.message, "error");
  }
}

async function deleteItem(scope, id) {
  const endpoints = {
    bridges: `/bridges/${id}`,
    inspectors: `/inspectors/${id}`,
    sensors: `/sensors/${id}`,
    users: `/auth/users/${id}`,
  };

  if (!endpoints[scope]) return;
  if (!window.confirm("Delete selected item?")) return;

  try {
    await api(endpoints[scope], { method: "DELETE" });
    state.editing = null;
    await loadViewData();
    renderShell();
    renderView();
    setToast("Deleted");
  } catch (error) {
    setToast(error.message, "error");
  }
}

function field(label, control) {
  return `
    <div class="field">
      <label>${label}</label>
      ${control}
    </div>
  `;
}

function select(key, value, items) {
  return `<select data-filter="${key}">${options(items, value)}</select>`;
}

function rawSelect(name, value, items, id = "") {
  return `<select ${id ? `id="${id}"` : ""} name="${name}">${options(items, value)}</select>`;
}

function options(items, value) {
  return items
    .map(([optionValue, label]) => `<option value="${escapeHtml(optionValue)}" ${String(optionValue) === String(value) ? "selected" : ""}>${escapeHtml(label)}</option>`)
    .join("");
}

function rowActions(scope, id, allowEdit, allowDelete) {
  return `
    <td>
      <div class="cell-actions">
        ${allowEdit ? `<button class="button" data-edit="${scope}:${id}" type="button">Edit</button>` : ""}
        ${allowDelete ? `<button class="button danger" data-delete="${scope}:${id}" type="button">Delete</button>` : ""}
      </div>
    </td>
  `;
}

function emptyState() {
  return `<div class="empty-state">No records</div>`;
}

function bridgeName(id) {
  return state.data.bridges.find((bridge) => bridge.id === id)?.name || `#${id}`;
}

function sensorName(id) {
  return state.data.sensors.find((sensor) => sensor.id === id)?.name || `#${id}`;
}

function inspectorName(id) {
  if (!id) return "";
  return state.data.inspectors.find((inspector) => inspector.id === id)?.full_name || "";
}

bootstrap();
