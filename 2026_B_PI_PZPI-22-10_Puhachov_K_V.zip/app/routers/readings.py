from datetime import datetime
from typing import Annotated

import os

from fastapi import APIRouter, Depends, Header, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.auth import get_current_user
from app.core.constants import PERIODS
from app.crud import readings as readings_crud
from app.crud import sensors as sensors_crud
from app.database.connection import get_db
from app.database.models import User
from app.schemas.readings import (
    SensorChartResponse,
    SensorReadingCreate,
    SensorReadingCreateResponse,
    SensorReadingResponse,
)
from app.services.monitoring import record_sensor_reading


router = APIRouter(
    prefix="/readings",
    tags=["Readings"],
)


DEVICE_INGEST_TOKEN = os.getenv("BRIDGE_DEVICE_INGEST_TOKEN", "dev-device-token")


@router.post(
    "",
    response_model=SensorReadingCreateResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_reading(
    reading_data: SensorReadingCreate,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    raise HTTPException(
        status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
        detail="Sensor readings are read-only for users and are ingested by devices.",
    )


@router.post(
    "/ingest",
    response_model=SensorReadingCreateResponse,
    status_code=status.HTTP_201_CREATED,
)
def ingest_reading(
    reading_data: SensorReadingCreate,
    x_device_token: str = Header(default=""),
    db: Session = Depends(get_db),
):
    if x_device_token != DEVICE_INGEST_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid device token",
        )

    sensor = sensors_crud.get_sensor_by_id(db=db, sensor_id=reading_data.sensor_id)
    if sensor is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sensor not found",
        )

    if not sensor.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Sensor is inactive",
        )

    reading, alert = record_sensor_reading(
        db=db,
        sensor=sensor,
        value=reading_data.value,
        recorded_at=reading_data.recorded_at,
    )
    return {
        "reading": reading,
        "alert": alert,
    }


@router.get("", response_model=list[SensorReadingResponse])
def get_readings(
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=1000)] = 100,
    sensor_id: Annotated[int | None, Query(gt=0)] = None,
    bridge_id: Annotated[int | None, Query(gt=0)] = None,
    start_at: datetime | None = None,
    end_at: datetime | None = None,
    sort_dir: Annotated[str, Query(pattern="^(asc|desc)$")] = "desc",
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return readings_crud.get_readings(
        db=db,
        skip=skip,
        limit=limit,
        sensor_id=sensor_id,
        bridge_id=bridge_id,
        start_at=start_at,
        end_at=end_at,
        sort_dir=sort_dir,
    )


@router.get("/sensors/{sensor_id}/chart", response_model=SensorChartResponse)
def get_sensor_chart(
    sensor_id: int,
    period: Annotated[str, Query(pattern="^(day|week|month)$")] = "day",
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    sensor = sensors_crud.get_sensor_by_id(db=db, sensor_id=sensor_id)
    if sensor is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sensor not found",
        )

    start_at = datetime.utcnow() - PERIODS[period]
    readings = readings_crud.get_readings(
        db=db,
        sensor_id=sensor_id,
        start_at=start_at,
        sort_dir="asc",
        limit=5000,
    )
    min_value, max_value, avg_value, count = readings_crud.get_reading_summary(
        db=db,
        sensor_id=sensor_id,
        start_at=start_at,
    )

    return {
        "sensor_id": sensor_id,
        "period": period,
        "points": [
            {
                "recorded_at": reading.recorded_at,
                "value": reading.value,
            }
            for reading in readings
        ],
        "summary": {
            "min_value": min_value,
            "max_value": max_value,
            "avg_value": avg_value,
            "count": count,
        },
    }


@router.get("/{reading_id}", response_model=SensorReadingResponse)
def get_reading(
    reading_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    reading = readings_crud.get_reading_by_id(db=db, reading_id=reading_id)
    if reading is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reading not found",
        )
    return reading
