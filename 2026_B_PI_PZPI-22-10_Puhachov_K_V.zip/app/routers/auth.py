from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.auth import get_current_user, require_roles
from app.core.security import create_access_token, verify_password
from app.crud import users as users_crud
from app.database.connection import get_db
from app.database.models import User
from app.schemas.common import DeleteResponse
from app.schemas.users import (
    TokenResponse,
    UserCreate,
    UserLogin,
    UserRegister,
    UserResponse,
    UserUpdate,
)


router = APIRouter(
    prefix="/auth",
    tags=["Auth"],
)


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register_user(
    user_data: UserRegister,
    db: Session = Depends(get_db),
):
    existing_user = users_crud.get_user_by_username(db=db, username=user_data.username)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Username already exists",
        )

    is_first_user = users_crud.count_users(db=db) == 0
    role = user_data.role if is_first_user else "user"
    if role is None:
        role = "admin" if is_first_user else "user"

    return users_crud.create_user(
        db=db,
        user_data=UserCreate(
            username=user_data.username,
            password=user_data.password,
            role=role,
        ),
    )


@router.post("/login", response_model=TokenResponse)
def login(
    credentials: UserLogin,
    db: Session = Depends(get_db),
):
    user = users_crud.get_user_by_username(db=db, username=credentials.username)
    if user is None or not verify_password(credentials.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
        )

    token, expires_at = create_access_token(subject=str(user.id), role=user.role)
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_at": expires_at,
        "user": user,
    }


@router.get("/me", response_model=UserResponse)
def get_me(current_user: User = Depends(get_current_user)):
    return current_user


@router.post("/users", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def create_user(
    user_data: UserCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    existing_user = users_crud.get_user_by_username(db=db, username=user_data.username)
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Username already exists",
        )

    return users_crud.create_user(db=db, user_data=user_data)


@router.get("/users", response_model=list[UserResponse])
def get_users(
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=200)] = 100,
    search: str | None = None,
    role: Annotated[str | None, Query(pattern="^(admin|inspector|user)$")] = None,
    sort_by: Annotated[
        str,
        Query(pattern="^(id|username|role|created_at)$"),
    ] = "id",
    sort_dir: Annotated[str, Query(pattern="^(asc|desc)$")] = "desc",
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    return users_crud.get_users(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        role=role,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )


@router.get("/users/{user_id}", response_model=UserResponse)
def get_user(
    user_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    user = users_crud.get_user_by_id(db=db, user_id=user_id)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )
    return user


@router.put("/users/{user_id}", response_model=UserResponse)
def update_user(
    user_id: int,
    user_data: UserUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    user = users_crud.get_user_by_id(db=db, user_id=user_id)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    if user_data.username and user_data.username != user.username:
        existing_user = users_crud.get_user_by_username(db=db, username=user_data.username)
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Username already exists",
            )

    return users_crud.update_user(db=db, user=user, user_data=user_data)


@router.delete("/users/{user_id}", response_model=DeleteResponse)
def delete_user(
    user_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_roles("admin")),
):
    user = users_crud.get_user_by_id(db=db, user_id=user_id)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )

    if user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You cannot delete your own account",
        )

    users_crud.delete_user(db=db, user=user)
    return {"message": "User deleted successfully"}
