from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.auth import get_current_user, require_roles
from app.crud import bridges as bridges_crud
from app.database.connection import get_db
from app.database.models import Alert, Inspector, Sensor, User
from app.schemas.bridges import (
    BridgeCreate,
    BridgeProblemsResponse,
    BridgeResponse,
    BridgeUpdate,
    DeleteResponse,
)


router = APIRouter(
    prefix="/bridges",
    tags=["Bridges"],
)


@router.post(
    "",
    response_model=BridgeResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_bridge(
    bridge_data: BridgeCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin", "inspector")),
):
    return bridges_crud.create_bridge(db=db, bridge_data=bridge_data)


@router.get(
    "",
    response_model=list[BridgeResponse],
)
def get_bridges(
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=200)] = 100,
    search: str | None = None,
    status_filter: Annotated[
        str | None,
        Query(alias="status", pattern="^(normal|warning|danger)$"),
    ] = None,
    sort_by: Annotated[
        str,
        Query(pattern="^(id|name|location|status|created_at)$"),
    ] = "id",
    sort_dir: Annotated[str, Query(pattern="^(asc|desc)$")] = "desc",
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return bridges_crud.get_bridges(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        status=status_filter,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )


@router.get(
    "/{bridge_id}",
    response_model=BridgeResponse,
)
def get_bridge(
    bridge_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    bridge = bridges_crud.get_bridge_by_id(db=db, bridge_id=bridge_id)

    if bridge is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bridge not found",
        )

    return bridge


@router.get(
    "/{bridge_id}/problems",
    response_model=BridgeProblemsResponse,
)
def get_bridge_problems(
    bridge_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    bridge = bridges_crud.get_bridge_by_id(db=db, bridge_id=bridge_id)

    if bridge is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bridge not found",
        )

    rows = (
        db.query(Alert, Sensor, Inspector)
        .join(Sensor, Sensor.id == Alert.sensor_id)
        .outerjoin(Inspector, Inspector.id == Sensor.responsible_inspector_id)
        .filter(Alert.bridge_id == bridge_id)
        .filter(Alert.is_resolved.is_(False))
        .order_by(Alert.created_at.desc())
        .all()
    )

    open_alerts = [
        {
            "id": alert.id,
            "alert_level": alert.alert_level,
            "value": alert.value,
            "message": alert.message,
            "is_resolved": alert.is_resolved,
            "created_at": alert.created_at,
            "sensor": {
                "id": sensor.id,
                "name": sensor.name,
                "sensor_type": sensor.sensor_type,
                "unit": sensor.unit,
                "manufacturer": sensor.manufacturer,
                "installed_by": sensor.installed_by,
                "responsible_inspector_id": sensor.responsible_inspector_id,
                "responsible_inspector_name": inspector.full_name if inspector else None,
                "description_uk": sensor.description_uk,
            },
        }
        for alert, sensor, inspector in rows
    ]

    if not open_alerts:
        reason = "Немає активних аварійних повідомлень для цього мосту."
    else:
        reason = (
            "Статус мосту сформовано на основі активних попереджень від "
            "датчиків, показання яких вийшли за допустимі межі."
        )

    return {
        "bridge": bridge,
        "open_alerts": open_alerts,
        "reason": reason,
    }


@router.put(
    "/{bridge_id}",
    response_model=BridgeResponse,
)
def update_bridge(
    bridge_id: int,
    bridge_data: BridgeUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin", "inspector")),
):
    bridge = bridges_crud.get_bridge_by_id(db=db, bridge_id=bridge_id)

    if bridge is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bridge not found",
        )

    return bridges_crud.update_bridge(
        db=db,
        bridge=bridge,
        bridge_data=bridge_data,
    )


@router.delete(
    "/{bridge_id}",
    response_model=DeleteResponse,
)
def delete_bridge(
    bridge_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    bridge = bridges_crud.get_bridge_by_id(db=db, bridge_id=bridge_id)

    if bridge is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bridge not found",
        )

    bridges_crud.delete_bridge(db=db, bridge=bridge)

    return {
        "message": "Bridge deleted successfully",
    }
