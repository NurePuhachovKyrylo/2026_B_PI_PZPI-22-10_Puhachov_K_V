from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.auth import get_current_user, require_roles
from app.crud import inspectors as inspectors_crud
from app.database.connection import get_db
from app.database.models import User
from app.schemas.common import DeleteResponse
from app.schemas.inspectors import InspectorCreate, InspectorResponse, InspectorUpdate


router = APIRouter(
    prefix="/inspectors",
    tags=["Inspectors"],
)


@router.post("", response_model=InspectorResponse, status_code=status.HTTP_201_CREATED)
def create_inspector(
    inspector_data: InspectorCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    existing_inspector = inspectors_crud.get_inspector_by_email(
        db=db,
        email=inspector_data.email,
    )
    if existing_inspector:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Inspector email already exists",
        )

    return inspectors_crud.create_inspector(db=db, inspector_data=inspector_data)


@router.get("", response_model=list[InspectorResponse])
def get_inspectors(
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=200)] = 100,
    search: str | None = None,
    sort_by: Annotated[
        str,
        Query(pattern="^(id|full_name|email|position|created_at)$"),
    ] = "id",
    sort_dir: Annotated[str, Query(pattern="^(asc|desc)$")] = "desc",
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return inspectors_crud.get_inspectors(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )


@router.get("/{inspector_id}", response_model=InspectorResponse)
def get_inspector(
    inspector_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    inspector = inspectors_crud.get_inspector_by_id(db=db, inspector_id=inspector_id)
    if inspector is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Inspector not found",
        )
    return inspector


@router.put("/{inspector_id}", response_model=InspectorResponse)
def update_inspector(
    inspector_id: int,
    inspector_data: InspectorUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    inspector = inspectors_crud.get_inspector_by_id(db=db, inspector_id=inspector_id)
    if inspector is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Inspector not found",
        )

    if inspector_data.email and inspector_data.email != inspector.email:
        existing_inspector = inspectors_crud.get_inspector_by_email(
            db=db,
            email=inspector_data.email,
        )
        if existing_inspector:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Inspector email already exists",
            )

    try:
        return inspectors_crud.update_inspector(
            db=db,
            inspector=inspector,
            inspector_data=inspector_data,
        )
    except IntegrityError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Inspector email already exists",
        )


@router.delete("/{inspector_id}", response_model=DeleteResponse)
def delete_inspector(
    inspector_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    inspector = inspectors_crud.get_inspector_by_id(db=db, inspector_id=inspector_id)
    if inspector is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Inspector not found",
        )

    inspectors_crud.delete_inspector(db=db, inspector=inspector)
    return {"message": "Inspector deleted successfully"}
