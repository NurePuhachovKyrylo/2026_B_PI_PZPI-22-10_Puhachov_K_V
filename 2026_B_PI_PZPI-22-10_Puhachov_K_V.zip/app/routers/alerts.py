from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session

from app.core.auth import get_current_user, require_roles
from app.crud import alerts as alerts_crud
from app.database.connection import get_db
from app.database.models import User
from app.schemas.alerts import AlertResponse, AlertUpdate
from app.services.monitoring import update_bridge_status


router = APIRouter(
    prefix="/alerts",
    tags=["Alerts"],
)


@router.get("", response_model=list[AlertResponse])
def get_alerts(
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=500)] = 100,
    search: str | None = None,
    bridge_id: Annotated[int | None, Query(gt=0)] = None,
    sensor_id: Annotated[int | None, Query(gt=0)] = None,
    alert_level: Annotated[str | None, Query(pattern="^(warning|danger)$")] = None,
    is_resolved: bool | None = None,
    sort_by: Annotated[
        str,
        Query(pattern="^(id|bridge_id|sensor_id|alert_level|is_resolved|created_at)$"),
    ] = "created_at",
    sort_dir: Annotated[str, Query(pattern="^(asc|desc)$")] = "desc",
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return alerts_crud.get_alerts(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        bridge_id=bridge_id,
        sensor_id=sensor_id,
        alert_level=alert_level,
        is_resolved=is_resolved,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )


@router.get("/{alert_id}", response_model=AlertResponse)
def get_alert(
    alert_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    alert = alerts_crud.get_alert_by_id(db=db, alert_id=alert_id)
    if alert is None:
        raise HTTPException(
            status_code=404,
            detail="Alert not found",
        )
    return alert


@router.put("/{alert_id}", response_model=AlertResponse)
def update_alert(
    alert_id: int,
    alert_data: AlertUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin", "inspector")),
):
    alert = alerts_crud.get_alert_by_id(db=db, alert_id=alert_id)
    if alert is None:
        raise HTTPException(
            status_code=404,
            detail="Alert not found",
        )

    updated_alert = alerts_crud.update_alert(db=db, alert=alert, alert_data=alert_data)
    update_bridge_status(db=db, bridge_id=updated_alert.bridge_id)
    db.commit()
    db.refresh(updated_alert)
    return updated_alert
