from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.orm import Session

from app.core.auth import get_current_user, require_roles
from app.core.constants import SENSOR_TYPES
from app.crud import bridges as bridges_crud
from app.crud import inspectors as inspectors_crud
from app.crud import sensors as sensors_crud
from app.database.connection import get_db
from app.database.models import Sensor
from app.database.models import User
from app.schemas.common import DeleteResponse
from app.schemas.sensors import (
    AvailableSensorInstall,
    AvailableSensorResponse,
    SensorCreate,
    SensorResponse,
    SensorTypeResponse,
    SensorUpdate,
)
from app.services.discovery import seed_available_sensors
from app.services.monitoring import update_bridge_status


router = APIRouter(
    prefix="/sensors",
    tags=["Sensors"],
)


@router.get("/types", response_model=list[SensorTypeResponse])
def get_sensor_types(_: User = Depends(get_current_user)):
    return [
        {
            "code": code,
            "label": sensor_type["label"],
            "default_unit": sensor_type["default_unit"],
            "default_min": sensor_type["default_min"],
            "default_max": sensor_type["default_max"],
        }
        for code, sensor_type in SENSOR_TYPES.items()
    ]


@router.post("", response_model=SensorResponse, status_code=status.HTTP_201_CREATED)
def create_sensor(
    sensor_data: SensorCreate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin", "inspector")),
):
    raise HTTPException(
        status_code=status.HTTP_405_METHOD_NOT_ALLOWED,
        detail="Sensors are installed from available discovered devices.",
    )


@router.get("/available", response_model=list[AvailableSensorResponse])
def get_available_sensors(
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=200)] = 100,
    search: str | None = None,
    sensor_type: Annotated[
        str | None,
        Query(
            pattern=(
                "^(temperature|vibration|humidity|deformation|pressure|wind|"
                "water_level|corrosion|other)$"
            )
        ),
    ] = None,
    is_installed: bool | None = None,
    sort_by: Annotated[
        str,
        Query(
            pattern=(
                "^(id|device_uid|name|sensor_type|manufacturer|"
                "is_installed|discovered_at)$"
            )
        ),
    ] = "discovered_at",
    sort_dir: Annotated[str, Query(pattern="^(asc|desc)$")] = "desc",
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return sensors_crud.get_available_sensors(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        sensor_type=sensor_type,
        is_installed=is_installed,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )


@router.post("/available/seed", response_model=list[AvailableSensorResponse])
def seed_available_sensor_catalog(
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    return seed_available_sensors(db=db)


@router.post("/available/{available_sensor_id}/install", response_model=SensorResponse)
def install_available_sensor(
    available_sensor_id: int,
    install_data: AvailableSensorInstall,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin", "inspector")),
):
    available_sensor = sensors_crud.get_available_sensor_by_id(
        db=db,
        available_sensor_id=available_sensor_id,
    )
    if available_sensor is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Available sensor not found",
        )

    if available_sensor.is_installed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Sensor is already installed",
        )

    bridge = bridges_crud.get_bridge_by_id(db=db, bridge_id=install_data.bridge_id)
    if bridge is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bridge not found",
        )

    if install_data.responsible_inspector_id:
        inspector = inspectors_crud.get_inspector_by_id(
            db=db,
            inspector_id=install_data.responsible_inspector_id,
        )
        if inspector is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Responsible inspector not found",
            )

    sensor = Sensor(
        bridge_id=install_data.bridge_id,
        name=available_sensor.name,
        sensor_type=available_sensor.sensor_type,
        unit=available_sensor.unit,
        min_value=available_sensor.min_value,
        max_value=available_sensor.max_value,
        is_active=True,
        available_sensor_id=available_sensor.id,
        manufacturer=available_sensor.manufacturer,
        installed_by=install_data.installed_by or available_sensor.installed_by,
        responsible_inspector_id=install_data.responsible_inspector_id,
        description_uk=available_sensor.description_uk,
    )
    db.add(sensor)
    db.commit()
    db.refresh(sensor)
    sensors_crud.mark_available_sensor_installed(
        db=db,
        available_sensor=available_sensor,
        installed_sensor=sensor,
    )
    return sensor


@router.get("", response_model=list[SensorResponse])
def get_sensors(
    skip: Annotated[int, Query(ge=0)] = 0,
    limit: Annotated[int, Query(ge=1, le=200)] = 100,
    search: str | None = None,
    bridge_id: Annotated[int | None, Query(gt=0)] = None,
    sensor_type: Annotated[
        str | None,
        Query(
            pattern=(
                "^(temperature|vibration|humidity|deformation|pressure|wind|"
                "water_level|corrosion|other)$"
            )
        ),
    ] = None,
    is_active: bool | None = None,
    sort_by: Annotated[
        str,
        Query(pattern="^(id|name|sensor_type|bridge_id|is_active|created_at)$"),
    ] = "id",
    sort_dir: Annotated[str, Query(pattern="^(asc|desc)$")] = "desc",
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    return sensors_crud.get_sensors(
        db=db,
        skip=skip,
        limit=limit,
        search=search,
        bridge_id=bridge_id,
        sensor_type=sensor_type,
        is_active=is_active,
        sort_by=sort_by,
        sort_dir=sort_dir,
    )


@router.get("/{sensor_id}", response_model=SensorResponse)
def get_sensor(
    sensor_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    sensor = sensors_crud.get_sensor_by_id(db=db, sensor_id=sensor_id)
    if sensor is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sensor not found",
        )
    return sensor


@router.put("/{sensor_id}", response_model=SensorResponse)
def update_sensor(
    sensor_id: int,
    sensor_data: SensorUpdate,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin", "inspector")),
):
    sensor = sensors_crud.get_sensor_by_id(db=db, sensor_id=sensor_id)
    if sensor is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sensor not found",
        )

    update_data = sensor_data.model_dump(exclude_unset=True)
    if sensor_data.bridge_id:
        bridge = bridges_crud.get_bridge_by_id(db=db, bridge_id=sensor_data.bridge_id)
        if bridge is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Bridge not found",
            )

    if sensor_data.responsible_inspector_id:
        inspector = inspectors_crud.get_inspector_by_id(
            db=db,
            inspector_id=sensor_data.responsible_inspector_id,
        )
        if inspector is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Responsible inspector not found",
            )

    old_bridge_id = sensor.bridge_id
    updated_sensor = sensors_crud.update_sensor(db=db, sensor=sensor, sensor_data=sensor_data)
    update_bridge_status(db=db, bridge_id=old_bridge_id)
    update_bridge_status(db=db, bridge_id=updated_sensor.bridge_id)
    db.commit()
    db.refresh(updated_sensor)
    return updated_sensor


@router.delete("/{sensor_id}", response_model=DeleteResponse)
def delete_sensor(
    sensor_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(require_roles("admin")),
):
    sensor = sensors_crud.get_sensor_by_id(db=db, sensor_id=sensor_id)
    if sensor is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sensor not found",
        )

    bridge_id = sensor.bridge_id
    available_sensor_id = sensor.available_sensor_id
    sensors_crud.delete_sensor(db=db, sensor=sensor)
    if available_sensor_id:
        sensors_crud.mark_available_sensor_uninstalled(
            db=db,
            available_sensor_id=available_sensor_id,
        )
    update_bridge_status(db=db, bridge_id=bridge_id)
    db.commit()
    return {"message": "Sensor deleted successfully"}
