from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


BridgeStatus = Literal["normal", "warning", "danger"]


class BridgeBase(BaseModel):
    name: str = Field(min_length=2, max_length=150)
    location: str = Field(min_length=2, max_length=255)
    description: str | None = None
    status: BridgeStatus = "normal"


class BridgeCreate(BridgeBase):
    pass


class BridgeUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=150)
    location: str | None = Field(default=None, min_length=2, max_length=255)
    description: str | None = None
    status: BridgeStatus | None = None


class BridgeResponse(BridgeBase):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class DeleteResponse(BaseModel):
    message: str


class BridgeProblemSensor(BaseModel):
    id: int
    name: str
    sensor_type: str
    unit: str
    manufacturer: str | None = None
    installed_by: str | None = None
    responsible_inspector_id: int | None = None
    responsible_inspector_name: str | None = None
    description_uk: str | None = None


class BridgeProblemAlert(BaseModel):
    id: int
    alert_level: str
    value: float
    message: str
    is_resolved: bool
    created_at: datetime
    sensor: BridgeProblemSensor


class BridgeProblemsResponse(BaseModel):
    bridge: BridgeResponse
    open_alerts: list[BridgeProblemAlert]
    reason: str
