from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class InspectorBase(BaseModel):
    full_name: str = Field(min_length=2, max_length=150)
    email: str = Field(min_length=5, max_length=150)
    phone: str | None = Field(default=None, max_length=50)
    position: str | None = Field(default=None, max_length=100)


class InspectorCreate(InspectorBase):
    pass


class InspectorUpdate(BaseModel):
    full_name: str | None = Field(default=None, min_length=2, max_length=150)
    email: str | None = Field(default=None, min_length=5, max_length=150)
    phone: str | None = Field(default=None, max_length=50)
    position: str | None = Field(default=None, max_length=100)


class InspectorResponse(InspectorBase):
    id: int
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
