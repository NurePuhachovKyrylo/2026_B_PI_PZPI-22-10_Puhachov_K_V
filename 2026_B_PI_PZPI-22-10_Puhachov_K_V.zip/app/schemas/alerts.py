from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict


AlertLevel = Literal["warning", "danger"]


class AlertResponse(BaseModel):
    id: int
    bridge_id: int
    sensor_id: int
    message: str
    value: float
    alert_level: AlertLevel
    is_resolved: bool
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AlertUpdate(BaseModel):
    is_resolved: bool
