from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


SensorType = Literal[
    "temperature",
    "vibration",
    "humidity",
    "deformation",
    "pressure",
    "wind",
    "water_level",
    "corrosion",
    "other",
]


class SensorBase(BaseModel):
    bridge_id: int = Field(gt=0)
    name: str = Field(min_length=2, max_length=150)
    sensor_type: SensorType
    unit: str = Field(min_length=1, max_length=30)
    min_value: float
    max_value: float
    is_active: bool = True
    available_sensor_id: int | None = Field(default=None, gt=0)
    manufacturer: str | None = Field(default=None, max_length=150)
    installed_by: str | None = Field(default=None, max_length=150)
    responsible_inspector_id: int | None = Field(default=None, gt=0)
    description_uk: str | None = None

    @model_validator(mode="after")
    def validate_limits(self) -> "SensorBase":
        if self.min_value >= self.max_value:
            raise ValueError("min_value must be less than max_value")
        return self


class SensorCreate(SensorBase):
    pass


class SensorUpdate(BaseModel):
    bridge_id: int | None = Field(default=None, gt=0)
    is_active: bool | None = None
    installed_by: str | None = Field(default=None, max_length=150)
    responsible_inspector_id: int | None = Field(default=None, gt=0)
    description_uk: str | None = None

    @model_validator(mode="after")
    def validate_limits(self) -> "SensorUpdate":
        return self


class SensorResponse(SensorBase):
    id: int
    installed_at: datetime | None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class SensorTypeResponse(BaseModel):
    code: str
    label: str
    default_unit: str
    default_min: float
    default_max: float


class AvailableSensorBase(BaseModel):
    device_uid: str = Field(min_length=3, max_length=100)
    name: str = Field(min_length=2, max_length=150)
    sensor_type: SensorType
    unit: str = Field(min_length=1, max_length=30)
    min_value: float
    max_value: float
    manufacturer: str = Field(min_length=2, max_length=150)
    installed_by: str | None = Field(default=None, max_length=150)
    description_uk: str | None = None

    @model_validator(mode="after")
    def validate_limits(self) -> "AvailableSensorBase":
        if self.min_value >= self.max_value:
            raise ValueError("min_value must be less than max_value")
        return self


class AvailableSensorCreate(AvailableSensorBase):
    pass


class AvailableSensorResponse(AvailableSensorBase):
    id: int
    is_installed: bool
    installed_sensor_id: int | None
    discovered_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AvailableSensorInstall(BaseModel):
    bridge_id: int = Field(gt=0)
    responsible_inspector_id: int | None = Field(default=None, gt=0)
    installed_by: str | None = Field(default=None, max_length=150)
