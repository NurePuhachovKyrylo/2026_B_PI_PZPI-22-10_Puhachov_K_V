from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from app.schemas.alerts import AlertResponse


Period = Literal["day", "week", "month"]


class SensorReadingCreate(BaseModel):
    sensor_id: int = Field(gt=0)
    value: float
    recorded_at: datetime | None = None


class SensorReadingResponse(BaseModel):
    id: int
    sensor_id: int
    value: float
    recorded_at: datetime

    model_config = ConfigDict(from_attributes=True)


class SensorReadingCreateResponse(BaseModel):
    reading: SensorReadingResponse
    alert: AlertResponse | None = None


class ChartPoint(BaseModel):
    recorded_at: datetime
    value: float


class ChartSummary(BaseModel):
    min_value: float | None
    max_value: float | None
    avg_value: float | None
    count: int


class SensorChartResponse(BaseModel):
    sensor_id: int
    period: Period
    points: list[ChartPoint]
    summary: ChartSummary
