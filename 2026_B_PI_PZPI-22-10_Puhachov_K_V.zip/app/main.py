from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.database.connection import Base, engine
from app.database import models
from app.database.migrations import run_lightweight_migrations
from app.routers import alerts, auth, bridges, inspectors, readings, sensors


BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIR = BASE_DIR / "frontend"
STATIC_DIR = FRONTEND_DIR / "static"


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    run_lightweight_migrations(engine)
    yield


app = FastAPI(
    title="Bridge Monitoring API",
    description="Backend API for bridge monitoring, sensors, alerts, users, and roles.",
    version="0.1.0",
    lifespan=lifespan,
)


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

app.include_router(auth.router)
app.include_router(bridges.router)
app.include_router(inspectors.router)
app.include_router(sensors.router)
app.include_router(readings.router)
app.include_router(alerts.router)


@app.get("/")
def root():
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/health")
def health_check():
    return {
        "status": "ok",
    }
