from sqlalchemy import text
from sqlalchemy.engine import Engine


def run_lightweight_migrations(engine: Engine) -> None:
    """Small SQLite migrations for this project without adding Alembic."""
    with engine.begin() as connection:
        sensor_columns = {
            row[1]
            for row in connection.execute(text("PRAGMA table_info(sensors)")).fetchall()
        }

        sensor_additions = {
            "available_sensor_id": "INTEGER",
            "manufacturer": "VARCHAR(150)",
            "installed_by": "VARCHAR(150)",
            "responsible_inspector_id": "INTEGER",
            "description_uk": "TEXT",
            "installed_at": "DATETIME",
        }

        for column_name, column_type in sensor_additions.items():
            if column_name not in sensor_columns:
                connection.execute(
                    text(f"ALTER TABLE sensors ADD COLUMN {column_name} {column_type}")
                )
