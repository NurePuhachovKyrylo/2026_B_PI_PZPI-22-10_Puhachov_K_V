from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.connection import Base


class Bridge(Base):
    __tablename__ = "bridges"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False, index=True)
    location: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="normal", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    sensors: Mapped[list["Sensor"]] = relationship(
        "Sensor",
        back_populates="bridge",
        cascade="all, delete-orphan",
    )

    alerts: Mapped[list["Alert"]] = relationship(
        "Alert",
        back_populates="bridge",
        cascade="all, delete-orphan",
    )


class Inspector(Base):
    __tablename__ = "inspectors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False, index=True)
    email: Mapped[str] = mapped_column(String(150), nullable=False, unique=True, index=True)
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    position: Mapped[str | None] = mapped_column(String(100), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    responsible_sensors: Mapped[list["Sensor"]] = relationship(
        "Sensor",
        back_populates="responsible_inspector",
    )


class AvailableSensor(Base):
    __tablename__ = "available_sensors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    device_uid: Mapped[str] = mapped_column(String(100), nullable=False, unique=True, index=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False, index=True)
    sensor_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    unit: Mapped[str] = mapped_column(String(30), nullable=False)
    min_value: Mapped[float] = mapped_column(Float, nullable=False)
    max_value: Mapped[float] = mapped_column(Float, nullable=False)
    manufacturer: Mapped[str] = mapped_column(String(150), nullable=False, index=True)
    installed_by: Mapped[str | None] = mapped_column(String(150), nullable=True)
    description_uk: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_installed: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    installed_sensor_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    discovered_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


class Sensor(Base):
    __tablename__ = "sensors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    bridge_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bridges.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    name: Mapped[str] = mapped_column(String(150), nullable=False, index=True)
    sensor_type: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    unit: Mapped[str] = mapped_column(String(30), nullable=False)
    min_value: Mapped[float] = mapped_column(Float, nullable=False)
    max_value: Mapped[float] = mapped_column(Float, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    available_sensor_id: Mapped[int | None] = mapped_column(Integer, nullable=True, index=True)
    manufacturer: Mapped[str | None] = mapped_column(String(150), nullable=True, index=True)
    installed_by: Mapped[str | None] = mapped_column(String(150), nullable=True)
    responsible_inspector_id: Mapped[int | None] = mapped_column(
        Integer,
        ForeignKey("inspectors.id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    description_uk: Mapped[str | None] = mapped_column(Text, nullable=True)
    installed_at: Mapped[datetime | None] = mapped_column(DateTime, default=datetime.utcnow)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    bridge: Mapped["Bridge"] = relationship(
        "Bridge",
        back_populates="sensors",
    )

    readings: Mapped[list["SensorReading"]] = relationship(
        "SensorReading",
        back_populates="sensor",
        cascade="all, delete-orphan",
    )

    alerts: Mapped[list["Alert"]] = relationship(
        "Alert",
        back_populates="sensor",
        cascade="all, delete-orphan",
    )

    responsible_inspector: Mapped["Inspector | None"] = relationship(
        "Inspector",
        back_populates="responsible_sensors",
    )


class SensorReading(Base):
    __tablename__ = "sensor_readings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    sensor_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("sensors.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    value: Mapped[float] = mapped_column(Float, nullable=False)
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    sensor: Mapped["Sensor"] = relationship(
        "Sensor",
        back_populates="readings",
    )


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    bridge_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("bridges.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    sensor_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("sensors.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    message: Mapped[str] = mapped_column(Text, nullable=False)
    value: Mapped[float] = mapped_column(Float, nullable=False)
    alert_level: Mapped[str] = mapped_column(String(30), nullable=False, default="warning", index=True)
    is_resolved: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)

    bridge: Mapped["Bridge"] = relationship(
        "Bridge",
        back_populates="alerts",
    )

    sensor: Mapped["Sensor"] = relationship(
        "Sensor",
        back_populates="alerts",
    )


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    username: Mapped[str] = mapped_column(String(100), nullable=False, unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[str] = mapped_column(String(30), nullable=False, default="user", index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
