from datetime import datetime

from sqlalchemy.orm import Session

from app.database.models import Alert, Bridge, Sensor, SensorReading


def determine_alert_level(sensor: Sensor, value: float) -> str | None:
    if sensor.min_value <= value <= sensor.max_value:
        return None

    safe_range = sensor.max_value - sensor.min_value
    if safe_range <= 0:
        safe_range = max(abs(sensor.max_value), 1.0)

    if value < sensor.min_value:
        distance = sensor.min_value - value
    else:
        distance = value - sensor.max_value

    return "danger" if distance / safe_range >= 0.2 else "warning"


def build_alert_message(sensor: Sensor, value: float, alert_level: str) -> str:
    if value < sensor.min_value:
        direction = "below"
        limit = sensor.min_value
    else:
        direction = "above"
        limit = sensor.max_value

    return (
        f"{alert_level.title()} value for sensor '{sensor.name}': "
        f"{value} {sensor.unit} is {direction} allowed limit {limit} {sensor.unit}."
    )


def update_bridge_status(db: Session, bridge_id: int) -> None:
    db.flush()

    bridge = db.query(Bridge).filter(Bridge.id == bridge_id).first()
    if bridge is None:
        return

    unresolved_alerts = (
        db.query(Alert)
        .filter(Alert.bridge_id == bridge_id)
        .filter(Alert.is_resolved.is_(False))
        .all()
    )

    if any(alert.alert_level == "danger" for alert in unresolved_alerts):
        bridge.status = "danger"
    elif unresolved_alerts:
        bridge.status = "warning"
    else:
        bridge.status = "normal"


def record_sensor_reading(
    db: Session,
    sensor: Sensor,
    value: float,
    recorded_at: datetime | None = None,
) -> tuple[SensorReading, Alert | None]:
    reading = SensorReading(
        sensor_id=sensor.id,
        value=value,
        recorded_at=recorded_at or datetime.utcnow(),
    )
    db.add(reading)
    db.flush()

    alert = None
    alert_level = determine_alert_level(sensor, value)
    if alert_level:
        alert = Alert(
            bridge_id=sensor.bridge_id,
            sensor_id=sensor.id,
            message=build_alert_message(sensor, value, alert_level),
            value=value,
            alert_level=alert_level,
        )
        db.add(alert)
        db.flush()

    update_bridge_status(db, sensor.bridge_id)
    db.commit()
    db.refresh(reading)
    if alert:
        db.refresh(alert)

    return reading, alert
