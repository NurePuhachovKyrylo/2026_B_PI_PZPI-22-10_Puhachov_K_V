from app.crud import sensors as sensors_crud
from app.database.models import AvailableSensor
from app.schemas.sensors import AvailableSensorCreate


TEST_AVAILABLE_SENSORS = [
    {
        "device_uid": "TM-BME280-001",
        "name": "BME280 temperature and humidity node",
        "sensor_type": "humidity",
        "unit": "%",
        "min_value": 0.0,
        "max_value": 95.0,
        "manufacturer": "Bosch Sensortec",
        "installed_by": "Auto-discovery test function",
        "description_uk": (
            "Датчик BME280 використовується для контролю вологості, температури "
            "та атмосферного тиску біля конструкцій мосту. Підвищена вологість "
            "може прискорювати корозію металевих елементів, погіршувати стан "
            "бетону та впливати на довгострокову надійність вузлів кріплення."
        ),
    },
    {
        "device_uid": "TM-ADXL355-001",
        "name": "ADXL355 vibration monitor",
        "sensor_type": "vibration",
        "unit": "mm/s",
        "min_value": 0.0,
        "max_value": 25.0,
        "manufacturer": "Analog Devices",
        "installed_by": "Auto-discovery test function",
        "description_uk": (
            "ADXL355 є малошумним тривісним акселерометром, який підходить для "
            "структурного моніторингу та контролю вібрацій. Для мостів такі "
            "показники допомагають помічати незвичні коливання від транспорту, "
            "вітру або пошкоджень опорних елементів."
        ),
    },
    {
        "device_uid": "TM-VW4430-001",
        "name": "VW deformation meter",
        "sensor_type": "deformation",
        "unit": "mm",
        "min_value": -8.0,
        "max_value": 8.0,
        "manufacturer": "GEOKON",
        "installed_by": "Auto-discovery test function",
        "description_uk": (
            "Вібраційно-струнний датчик деформації застосовується для тривалого "
            "контролю зміщень і розкриття стиків мостової конструкції. Вихід за "
            "допустимі межі може вказувати на перевантаження, температурні "
            "деформації або розвиток конструктивного дефекту."
        ),
    },
    {
        "device_uid": "TM-TEMP-001",
        "name": "Outdoor temperature probe",
        "sensor_type": "temperature",
        "unit": "C",
        "min_value": -30.0,
        "max_value": 70.0,
        "manufacturer": "Milesight",
        "installed_by": "Auto-discovery test function",
        "description_uk": (
            "Температурний датчик потрібен для оцінки умов експлуатації мосту та "
            "пояснення сезонних деформацій. Різкі або екстремальні температури "
            "можуть впливати на розширення матеріалів, стан швів та роботу "
            "інших вимірювальних каналів."
        ),
    },
]


def seed_available_sensors(db) -> list[AvailableSensor]:
    sensors = []
    for sensor_data in TEST_AVAILABLE_SENSORS:
        available_sensor = sensors_crud.get_available_sensor_by_uid(
            db=db,
            device_uid=sensor_data["device_uid"],
        )
        if available_sensor is None:
            available_sensor = sensors_crud.create_available_sensor(
                db=db,
                sensor_data=AvailableSensorCreate(**sensor_data),
            )
        sensors.append(available_sensor)
    return sensors
