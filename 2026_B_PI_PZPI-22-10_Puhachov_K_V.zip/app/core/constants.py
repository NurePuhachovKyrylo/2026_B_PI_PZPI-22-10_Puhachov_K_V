from datetime import timedelta


BRIDGE_STATUSES = {"normal", "warning", "danger"}
ALERT_LEVELS = {"warning", "danger"}
USER_ROLES = {"admin", "inspector", "user"}

SENSOR_TYPES = {
    "temperature": {
        "label": "Temperature",
        "default_unit": "C",
        "default_min": -40.0,
        "default_max": 80.0,
    },
    "vibration": {
        "label": "Vibration",
        "default_unit": "mm/s",
        "default_min": 0.0,
        "default_max": 25.0,
    },
    "humidity": {
        "label": "Humidity",
        "default_unit": "%",
        "default_min": 0.0,
        "default_max": 100.0,
    },
    "deformation": {
        "label": "Deformation",
        "default_unit": "mm",
        "default_min": -10.0,
        "default_max": 10.0,
    },
    "pressure": {
        "label": "Pressure",
        "default_unit": "kPa",
        "default_min": 80.0,
        "default_max": 140.0,
    },
    "wind": {
        "label": "Wind speed",
        "default_unit": "m/s",
        "default_min": 0.0,
        "default_max": 30.0,
    },
    "water_level": {
        "label": "Water level",
        "default_unit": "m",
        "default_min": 0.0,
        "default_max": 12.0,
    },
    "corrosion": {
        "label": "Corrosion",
        "default_unit": "%",
        "default_min": 0.0,
        "default_max": 35.0,
    },
    "other": {
        "label": "Other indicator",
        "default_unit": "unit",
        "default_min": 0.0,
        "default_max": 100.0,
    },
}

PERIODS = {
    "day": timedelta(days=1),
    "week": timedelta(days=7),
    "month": timedelta(days=30),
}
